//#include <iostream>
//#include <string>
//#include <thread>
//#include <vector>
//#include <cstdlib>
//#include <cstdio>
//#include <winKeyPressH.hpp>
//#include <unistd.h>
//
//bool start = true;
//
//void find_img()
//{
//    ImageEvent imge;
//    KeyBoardEvent kbd;
//    while ( start)
//    {
//        string keyNameArr[] = {"../keydown/up.png", "../keydown/down.png", "../keydown/right.png"};
//        for (auto &i : keyNameArr)
//        {
//            try
//            {
//                cout<<i<<endl;
//                imge.GetImagePosition(i, 0.75);
//                if (i =="../keydown/up.png")
//                {
//                    kbd.PressKey("up_arrow");
//                    cout<<"press up\n";
//                }
//                else if (i =="../keydown/down.png")
//                {
//                    kbd.PressKey("down_arrow");
//                    cout<<"press down\n";
//                }
//                else if (i =="../keydown/right.png")
//                {
//                    kbd.PressKey("right_arrow");
//                    cout<<"press right\n";
//                }
//            }
//            catch (const std::exception &e)
//            {
//                std::cerr << e.what() << '\n';
//                continue;
//            }
//        }
//    }
//}
//
//
//int main()
//{
////    if (!wkp::isAdmin())
////    {
////        wkp::openAdmin();
////        return 0;
////    }
////    KeyBoardEvent kbd;
////    thread T1(find_img);
////    T1.detach();
////    kbd.AddHotKey("p", [&](){
////        start = false;
////        KeyBoardEvent::ClearHotKey();
////    });
////    kbd.WaitHotKey();
//    KeyBoardEvent kbd;
//    return 0;
//}

#include <iostream>
#include <vector>
#include <WinKeyPressH.hpp>

//int main()
//{
//    FileEvent fl;
//    string p1 = "E:\\AToPythonCPP";
//    string p2 = "F:\\AToPythonCPP";
//    string p3 = "G:\\AToPythonCPP";
//    string p4 = "H:\\AToPythonCPP";
//    string p5 = "I:\\AToPythonCPP";
//    fl.RemoveDir(p1);
//    fl.RemoveDir(p2);
//    fl.RemoveDir(p3);
//    fl.RemoveDir(p4);
//    fl.RemoveDir(p5);
//    return 0;
//}