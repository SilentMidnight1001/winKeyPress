#include <iostream>
#include <windows.h>
#include <cstdio>
#include <ctime>
#include <unistd.h> // For sleep()
#include <csignal> // For signal()
#include <regex>  // 正则表达头文件
#include <vector>  // 自动管理内存
#include <thread>
#include <functional>
#include <cctype>
#include <chrono>
#include <opencv2/opencv.hpp>
#include "winKeyPressH.hpp"
using namespace std;
using namespace cv;
namespace fs = std::filesystem;

static StringCode scd_cpp;

// 全局互斥锁 //
std::mutex mtx;

/*********** 虚键码对照表 Virtual key code mapping table **************/
string alphabet_list[] = {"a", "b", "c", "d", "e", "f", "g",
                          "h", "i", "j", "k", "l", "m",
                          "n", "o", "p", "q", "r", "s",
                          "t", "u", "v", "w", "x", "y", "z"  // 26字母
        ,"0", "1", "2", "3", "4", "5", "6"
        , "7", "8", "9"};  // 按键列  // 字母列表


string function_keys_list [] = {"ctrl", "alt", "shift", "f1", "f2", "f3", "f4", "f5",
                                "f6", "f7", "f8", "f9", "f10", "f11", "f12", "esc",
                                "space", "delete", "tab", "enter", "caps", "clear",
                                "backspace", "win", "pause", "page_up", "page_down", "left_arrow",
                                "right_arrow", "down_arrow", "up_arrow", "insert", "`", "[", "]",
                                "\\", ";", "''", ",", ".", "/","-", "=", "，",
                                "。", "’", "‘"

};

/****************************虚键码列表********************************/
int alphabet_code[] = {65, 66, 67, 68, 69, 70,
                       71, 72, 73, 74, 75, 76,
                       77, 78, 79, 80, 81, 82,
                       83, 84, 85, 86, 87, 88,
                       89, 90, 48, 49, 50, 51,  // 48 以后是数组
                       52, 53, 54, 55, 56, 57};  // 虚拟键码

int function_code[] = {VK_CONTROL, VK_MENU, VK_SHIFT, VK_F1, VK_F2, VK_F3,
                       VK_F4, VK_F5, VK_F6, VK_F7, VK_F8, VK_F9, VK_F10,
                       VK_F11, VK_F12, VK_ESCAPE, VK_SPACE, VK_DELETE, VK_TAB,
                       VK_RETURN, VK_CAPITAL, VK_CLEAR, VK_BACK, VK_LWIN, VK_PAUSE,
                       VK_PRIOR, VK_NEXT, VK_LEFT, VK_RIGHT, VK_DOWN, VK_UP, VK_INSERT,
                       VK_OEM_3, VK_OEM_4, VK_OEM_6, VK_OEM_5, VK_OEM_1, VK_OEM_7, 188,
                       190, VK_OEM_2, VK_OEM_MINUS, VK_OEM_PLUS, 188, 190, VK_OEM_7,
                       VK_OEM_7
};


/**************************** 符合虚键码列表 ********************************/
string symbol_list_not_shift_press[] = {"`", "[", "]", "\\", ";", "''", ",", ".", "/",
                                        "-", "=", "，", "。", "’", "‘"};

string symbol_list_need_shift_press[] = {"~", "{", "}", "|", ":", "\"\"", "<", ">", "?",
                                         "_", "+","!", "@", "#", "$", "%", "^",
                                         "&", "*", "(",")"};

string chinese_symbol_shift_press[] = {"：", "“”", "《", "》", "？",
                                       "——", "！" , "￥", "……","（","）"};

//虚键码列表//
int symbol_not_shift_code[] = {VK_OEM_3, VK_OEM_4, VK_OEM_6, VK_OEM_5, VK_OEM_1, VK_OEM_7, 188,
                               190, VK_OEM_2, VK_OEM_MINUS, VK_OEM_PLUS, 188, 190, VK_OEM_7,
                               VK_OEM_7};

int symbol_need_shift_code[] = {VK_OEM_3, VK_OEM_4, VK_OEM_6, VK_OEM_5, VK_OEM_1, VK_OEM_7, 188,
                                190, VK_OEM_2, VK_OEM_MINUS, VK_OEM_PLUS, 49,
                                50, 51,52, 53, 54, 55, 56, 57, 48 };

int chinese_symbol_shift_code[] = {VK_OEM_1, VK_OEM_7, 188,190, VK_OEM_2,
                                   VK_OEM_MINUS,  49,52, 53, 57, 48 };


/************** 屏幕事件 **************/
ScreenSize GetScreenSize(bool out_put=True)
{
    ScreenSize screen_size;
    int x_len, y_len;
    x_len=GetSystemMetrics(SM_CXSCREEN);  // 获取x长度
    y_len=GetSystemMetrics(SM_CYSCREEN);  // 获取y长度
    screen_size.x = x_len;  // 结构体储存大小(屏幕)
    screen_size.y = y_len;  // 结构体储存大小(屏幕)
    if (out_put)
    {
        printf("Display size x:%d, y:%d\n", screen_size.x, screen_size.y);
    }
    return screen_size;
//    If you want to get coordinates you need to instantiate the struct function:
//    ScreenSizeGet screen_size = GetScreenSIze; screen_size.x, screen_size.y
}

/******************** 获取图像坐标 ********************/

// 函数：captureScreen - 捕获当前屏幕截图并返回 OpenCV Mat 对象 //
cv::Mat captureScreen()
{
    // 获取整个屏幕的设备上下文（DC）
    HDC hDC = GetDC(NULL);
    // 获取虚拟屏幕的尺寸（多显示器情况下）
    int width = GetSystemMetrics(SM_CXVIRTUALSCREEN);
    int height = GetSystemMetrics(SM_CYVIRTUALSCREEN);
    int x = GetSystemMetrics(SM_XVIRTUALSCREEN);  // 虚拟屏幕左上角 X 坐标
    int y = GetSystemMetrics(SM_YVIRTUALSCREEN);  // 虚拟屏幕左上角 Y 坐标

    // 创建与屏幕兼容的内存设备上下文
    HDC memDC = CreateCompatibleDC(hDC);
    // 创建兼容位图（尺寸与屏幕相同）
    HBITMAP hBitmap = CreateCompatibleBitmap(hDC, width, height);
    // 将位图选入内存 DC
    SelectObject(memDC, hBitmap);

    // 将屏幕内容复制到内存 DC（从屏幕 DC 到内存 DC）
    BitBlt(memDC, 0, 0, width, height, hDC, x, y, SRCCOPY);

    // 创建 OpenCV Mat 对象存储截图（32 位 BGRA 格式）
    cv::Mat screenshot(height, width, CV_8UC4);
    // 配置位图信息头
    BITMAPINFO bmi;
    ZeroMemory(&bmi, sizeof(BITMAPINFO));  // 清空结构体
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = width;
    bmi.bmiHeader.biHeight = -height;  // 负数表示从上到下排列像素
    bmi.bmiHeader.biPlanes = 1;        // 颜色平面数（必须为 1）
    bmi.bmiHeader.biBitCount = 32;     // 每像素 32 位（BGRA）
    bmi.bmiHeader.biCompression = BI_RGB;  // 无压缩
    // 从位图数据填充 Mat 对象
    GetDIBits(memDC, hBitmap, 0, height, screenshot.data, &bmi, DIB_RGB_COLORS);

    // 清理资源
    DeleteObject(hBitmap);  // 删除位图对象
    DeleteDC(memDC);        // 删除内存 DC
    ReleaseDC(NULL, hDC);   // 释放屏幕 DC

    // 将 BGRA 转换为 BGR（移除 Alpha 通道）
    cv::cvtColor(screenshot, screenshot, cv::COLOR_BGRA2BGR);
    return screenshot;
}

// 获取图像坐标函数,将此函数移到图像操作中 //
ImagePosition ImageEvent:: GetImagePosition(const string& filePath, double threshold)
{
    ImagePosition position;
    // 设置进程 DPI 感知级别，确保在高 DPI 屏幕上正确获取坐标
    SetProcessDPIAware();
//    SetProcessDpiAwareness(PROCESS_PER_MONITOR_DPI_AWARE);

    // 捕获屏幕截图
    cv::Mat screenshot = captureScreen();

    // 加载模板图像（需确保 "img.png" 位于工作目录或提供绝对路径）
    cv::Mat templateImg = cv::imread(filePath);
    if (templateImg.empty())
    {
        throw ImageNotFoundException("The template image cannot be loaded!");
    }

    // 检查模板尺寸是否超过屏幕截图
    if (templateImg.rows > screenshot.rows || templateImg.cols > screenshot.cols)
    {
        throw ImageNotFoundException("The template image is too large and cannot be matched!");
    }

    // 执行模板匹配（使用归一化相关系数法）
    cv::Mat result;
    cv::matchTemplate(screenshot, templateImg, result, cv::TM_CCOEFF_NORMED);

    // 获取匹配结果中的最值及其位置
    double minVal, maxVal;
    cv::Point minLoc, maxLoc;
    cv::minMaxLoc(result, &minVal, &maxVal, &minLoc, &maxLoc);

    if (maxVal >= threshold) {
        // 计算目标区域坐标
        cv::Point topLeft = maxLoc;
        cv::Point bottomRight(maxLoc.x + templateImg.cols, maxLoc.y + templateImg.rows);

        // 计算目标中心坐标
        int x = topLeft.x + templateImg.cols / 2;
        int y = topLeft.y + templateImg.rows / 2;

        position.x = x;
        position.y = y;
        position.result = true;
        return position;

        // （可选）在截图上绘制绿色矩形框并显示
        // cv::rectangle(screenshot, topLeft, bottomRight, cv::Scalar(0, 255, 0), 2);
        // cv::imshow("Screen with Match", screenshot);
        // cv::waitKey(0);
    }
    else
    {
        throw ImageNotFoundException("Image not find!");
    }
}

// 设置图片格式 //
bool ImageEvent:: SetImageFormat(const string &imgPath, const string &targetImageFormat)
{
    // 1. 读取图片（支持JPG/PNG/BMP等）
    Mat image = imread(imgPath);

    // 2. 检查是否读取成功
    if (image.empty())
    {
        std::cerr<<"Image reading failed!\n";
        return false;
    }

    // 3. 转换并保存为不同格式
    bool success = imwrite(targetImageFormat, image);  // 转为PNG

    // 检查保存结果
    if (!success)
    {
        std::cerr<<"Image save failed!\n";
        return false;
    }
    return true;
}


// 全局截图 //
bool ImageEvent::SaveBitmapToFile(HBITMAP hBitmap, const wchar_t *filename)
{
    HRESULT hr = S_OK;

    IWICImagingFactory* pFactory = nullptr;
    IWICBitmap* pWICBitmap = nullptr;
    IWICStream* pStream = nullptr;
    IWICBitmapEncoder* pEncoder = nullptr;
    IWICBitmapFrameEncode* pFrameEncode = nullptr;
    IPropertyBag2* pPropertybag = nullptr;

    // 创建 WIC 工厂
    hr = CoCreateInstance(
            CLSID_WICImagingFactory,
            nullptr,
            CLSCTX_INPROC_SERVER,
            IID_PPV_ARGS(&pFactory)
    );

    if (FAILED(hr)) return false;

    // 将 HBITMAP 转换为 WIC 位图
    hr = pFactory->CreateBitmapFromHBITMAP(
            hBitmap,
            nullptr,
            WICBitmapUseAlpha,
            &pWICBitmap
    );

    if (FAILED(hr)) {
        pFactory->Release();
        return false;
    }

    // 创建文件流
    hr = pFactory->CreateStream(&pStream);
    if (FAILED(hr)) goto CLEANUP;

    hr = pStream->InitializeFromFilename(filename, GENERIC_WRITE);
    if (FAILED(hr)) goto CLEANUP;

    // 创建 PNG 编码器
    hr = pFactory->CreateEncoder(
            GUID_ContainerFormatPng,
            nullptr,
            &pEncoder
    );

    if (FAILED(hr)) goto CLEANUP;

    hr = pEncoder->Initialize(pStream, WICBitmapEncoderNoCache);
    if (FAILED(hr)) goto CLEANUP;

    // 创建新帧
    hr = pEncoder->CreateNewFrame(&pFrameEncode, &pPropertybag);
    if (FAILED(hr)) goto CLEANUP;

    hr = pFrameEncode->Initialize(pPropertybag);
    if (FAILED(hr)) goto CLEANUP;

    // 设置帧尺寸
    UINT width, height;
    pWICBitmap->GetSize(&width, &height);
    hr = pFrameEncode->SetSize(width, height);
    if (FAILED(hr)) goto CLEANUP;

    // 获取并设置像素格式
    WICPixelFormatGUID pixelFormat;
    pWICBitmap->GetPixelFormat(&pixelFormat);
    hr = pFrameEncode->SetPixelFormat(&pixelFormat);
    if (FAILED(hr)) goto CLEANUP;

    // 写入位图数据
    hr = pFrameEncode->WriteSource(pWICBitmap, nullptr);
    if (FAILED(hr)) goto CLEANUP;

    // 提交更改
    hr = pFrameEncode->Commit();
    if (FAILED(hr)) goto CLEANUP;

    hr = pEncoder->Commit();
    if (FAILED(hr)) goto CLEANUP;

    CLEANUP:
    if (pPropertybag) pPropertybag->Release();
    if (pFrameEncode) pFrameEncode->Release();
    if (pEncoder) pEncoder->Release();
    if (pStream) pStream->Release();
    if (pWICBitmap) pWICBitmap->Release();
    if (pFactory) pFactory->Release();

    return SUCCEEDED(hr);
}

// 截图功能 //
bool ImageEvent::CaptureScreen(const std::string& imageName)
{
    // 初始化COM库（确保在程序启动时调用一次）
    static bool comInitialized = false;
    if (!comInitialized)
    {
        CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
        comInitialized = true;
    }

    HDC hdcScreen = nullptr;
    HDC hdcMem = nullptr;
    HBITMAP hBitmap = nullptr;

    StringCode scd;
    std::string fullName = imageName + ".png";
    std::wstring fileName = scd.StrToWStr(fullName);
    const wchar_t* filename = fileName.c_str();

    SetProcessDPIAware();
//    SetProcessDpiAwareness(PROCESS_PER_MONITOR_DPI_AWARE);

    int screenWidth = GetSystemMetrics(SM_CXVIRTUALSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYVIRTUALSCREEN);

    hdcScreen = GetDC(nullptr);
    hdcMem = CreateCompatibleDC(hdcScreen);
    hBitmap = CreateCompatibleBitmap(hdcScreen, screenWidth, screenHeight);

    if (!hBitmap)
    {
        DeleteDC(hdcMem);
        ReleaseDC(nullptr, hdcScreen);
        std::cerr <<"Image saving failed!\n";
        return false;
    }

    SelectObject(hdcMem, hBitmap);
    BitBlt(hdcMem, 0, 0, screenWidth, screenHeight, hdcScreen, 0, 0, SRCCOPY);

    if (!SaveBitmapToFile(hBitmap, filename))
    {
        std::cerr <<"Image saving failed!\n";
        return false;
    }

    // 正确释放资源
    ReleaseDC(nullptr, hdcScreen);
    DeleteDC(hdcMem);
    DeleteObject(hBitmap);
    isCaptureScreen = true;
    return true;
}

bool ImageEvent::CaptureScreen(const string &imageName, const string &targetImageSavePath)
{
    // 初始化COM库（确保在程序启动时调用一次）
    static bool comInitialized = false;
    if (!comInitialized)
    {
        CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
        comInitialized = true;
    }

    HDC hdcScreen = nullptr;
    HDC hdcMem = nullptr;
    HBITMAP hBitmap = nullptr;

    StringCode scd;
    std::string fullName = imageName + ".png";
    std::wstring fileName = scd.StrToWStr(fullName);
    const wchar_t* filename = fileName.c_str();

    SetProcessDPIAware();
//    SetProcessDpiAwareness(PROCESS_PER_MONITOR_DPI_AWARE);

    int screenWidth = GetSystemMetrics(SM_CXVIRTUALSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYVIRTUALSCREEN);

    hdcScreen = GetDC(nullptr);
    hdcMem = CreateCompatibleDC(hdcScreen);
    hBitmap = CreateCompatibleBitmap(hdcScreen, screenWidth, screenHeight);

    if (!hBitmap)
    {
        DeleteDC(hdcMem);
        ReleaseDC(nullptr, hdcScreen);
        std::cerr <<"Image saving failed!\n";
        return false;
    }

    SelectObject(hdcMem, hBitmap);
    BitBlt(hdcMem, 0, 0, screenWidth, screenHeight, hdcScreen, 0, 0, SRCCOPY);

    wstring savePath = scd.StrToWStr(targetImageSavePath+"/");
    savePath += fileName;
    if (!SaveBitmapToFile(hBitmap, savePath.c_str()))
    {
        std::cerr <<"Image saving failed!\n";
        return false;
    }

    // 正确释放资源
    ReleaseDC(nullptr, hdcScreen);
    DeleteDC(hdcMem);
    DeleteObject(hBitmap);
    isCaptureScreen = true;
    return true;
}

// 获取路径图片名称 //
string ImageEvent::getImageNameFunc(const string &imgPath)
{
    // 输出原本图片名称+格式 //
    string str = imgPath;
    // 参数获取后缀名称 //
    std::regex pattern(R"((\w+)\.(\w+))");
    // 用于存储匹配结果的std::smatch对象
    std::smatch match;

    // 局部搜索 //
    if (std::regex_search(str, match, pattern))
    {
        // 获取捕获组，[0]是整个匹配的结果，[1]开始是捕获组 //
        string str = match[1].str();
        string str2 = match[2].str();
        // 组合名称 //
        string fileName = str + "." + str2;
        cout<<fileName<<endl;
        return fileName;
    }
    // 匹配失败返回空字符串 //
    return "";
}

string ImageEvent::getImageNameFunc(const string &imgPath, const string &name)
{
    // 仅仅输出图片格式 //
    string str = imgPath;
    // 参数获取后缀名称 //
    std::regex pattern(R"((\w+)\.(\w+))");
    // 用于存储匹配结果的std::smatch对象
    std::smatch match;

    // 检查是否为空名称 //
    if (!name.empty())
    {
        // 局部搜索 //
        if (std::regex_search(str, match, pattern))
        {
            // 获取捕获组，[0]是整个匹配的结果，[1]开始是捕获组 //
            string str2 = match[2].str();
            // 组合名称 //
            string fileName = name + "." + str2;
            return fileName;
        }
    }
    else
    {
        string fileName = getImageNameFunc(imgPath);
        return fileName;
    }
    // 匹配失败返回空字符串 //
    return "";
}

// 设置图片尺寸 //
bool ImageEvent::SetImageSize(const string &imgPath, int width, int height, const string &targetImageSavePath, const string &outPutName)
{
    // 保存图片大小 //
    // 读取图像 //
    cv::Mat src = cv::imread(imgPath);
    if (src.empty())
    {
        std::cerr << "image not find!" << std::endl;
        return false;
    }

    // 调整尺寸为 800x600，使用双三次插值 //
    cv::Mat dst;
    cv::resize(src, dst, cv::Size(width, height), 0, 0, cv::INTER_CUBIC);

    // 保存结果 //
    string saveImageName = targetImageSavePath+"/"+getImageNameFunc(imgPath, outPutName);
    cv::imwrite(saveImageName, dst);
    return true;
}

bool ImageEvent::SetImageSize(const string &imgPath, int width, int height)
{
    // 读取图像 //
    cv::Mat src = cv::imread(imgPath);
    if (src.empty())
    {
        std::cerr << "image not find!" << std::endl;
        return false;
    }

    // 调整尺寸为 800x600，使用双三次插值 //
    cv::Mat dst;
    cv::resize(src, dst, cv::Size(width, height), 0, 0, cv::INTER_CUBIC);

    // 保存结果 //
    string saveImageName = getImageNameFunc(imgPath);
    cv::imwrite(saveImageName, dst);
    return true;
}


bool ImageEvent::SetImageSize(const string &imgPath, int width, int height, const string &outPutName)
{
    // 读取图像 //
    cv::Mat src = cv::imread(imgPath);
    if (src.empty())
    {
        std::cerr << "image not find!" << std::endl;
        return false;
    }

    // 调整尺寸为 800x600，使用双三次插值 //
    cv::Mat dst;
    cv::resize(src, dst, cv::Size(width, height), 0, 0, cv::INTER_CUBIC);

    // 保存结果 //
    string saveImageName = getImageNameFunc(imgPath, outPutName);
    cv::imwrite(saveImageName, dst);
    return true;
}




ImageEvent::~ImageEvent()
{
    if (isCaptureScreen)
    {
        // 释放 COM 资源
        CoUninitialize();
    }
}
/************************获取光标坐标*******************************/
MousePosition GetMousePosition(bool out_put=True)  // 获取光标目前所在的坐标
{
    POINT cursorPos;  // 实例化光标结构体，获取位置
    MousePosition mouse_position;  // 实力结构体取其中变量
    if (GetCursorPos(&cursorPos))
    {
        if (out_put)
        {
            printf("The current position of the cursor is x:%ld, y:%ld\n", cursorPos.x, cursorPos.y);
        }
        mouse_position.x = cursorPos.x;
        mouse_position.y = cursorPos.y;
        return mouse_position;  // 返回这个实例化的坐标，如果想要拿到坐标需要实例化
        // 获取坐标需要实力化结构体如和将函数的值复制在结构体实例的变量中当做参数传给结构体再获取
//        If you want to get coordinates you need to instantiate the struct function:
//        MousePositionGet mouse_position = GetMousePosition(); mouse_position.x,mouse_position.y
    }
    else
    {
        printf("Sorry, cursor coordinates not found\n");
        return mouse_position;
    }

}

/***************** 鼠标事件的类 *******************/

void MouseEvent::MouseMoveTo(int x, int y)  // MouseMoveTo是void类型
{
    SetCursorPos(x, y);  // 移动鼠标到某处(设置光标位置)
}

void MouseEvent::MouseClick(int x, int y, int clicks=1, const string& button="left")
{
    /* 当click为1时并且button不为None时执行单击一次的指令 */
    SetCursorPos(x, y);  // 移动鼠标到某处(设置光标位置)
    if (clicks!=0)
    {
        int click_time = 0;  // 初始化点击次数
        while (click_time <clicks && button== "left")  // 当初始点击次数小于目标点击次数增
        {
            // 如果没传参数默认左键
            INPUT input = {0};  // 定义INPUT结构体变量表示输入事件信息
            input.type = INPUT_MOUSE;  // 指定输入事件类型为鼠标事件
            input.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;  // 设定鼠标事件为左键按下
            SendInput(1, &input, sizeof(INPUT));  // 使用SendInput函数发送鼠标事件

            input.mi.dwFlags = MOUSEEVENTF_LEFTUP;  // 设定鼠标事件为左键释放
            SendInput(1, &input, sizeof(INPUT));  // 发送释放鼠标左键事件
            click_time++;
        }

        while (click_time <clicks && button == "right")  // 当初始点击次数小于目标点击次数增加
        {
            INPUT input = {0};  // 定义INPUT结构体变量表示输入事件信息
            input.type = INPUT_MOUSE;  // 指定输入事件类型为鼠标事件
            input.mi.dwFlags = MOUSEEVENTF_RIGHTDOWN;  // 设定鼠标事件为左键按下
            SendInput(1, &input, sizeof(INPUT));  // 使用SendInput函数发送鼠标事件


            input.mi.dwFlags = MOUSEEVENTF_RIGHTUP;  // 设定鼠标事件为右键释放
            SendInput(1, &input, sizeof(INPUT));  // 发送释放鼠标右键事件
            click_time++;  // 初始值增加
        }
    }
}

void MouseEvent::MouseClick(MousePosition &positions, int clicks, const string& button)
{
    MouseClick(positions.x, positions.y, clicks, button);
}

void MouseEvent::MouseClick(int x, int y)
{
    MouseClick(x, y, 1, "left");
}


void MouseEvent::MouseDown(const string& button="left")
{
    if (button == "left")
    {
        // 如果没传参数默认左键
        INPUT input = {0};  // 定义INPUT结构体变量表示输入事件信息
        input.type = INPUT_MOUSE;  // 指定输入事件类型为鼠标事件
        input.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;  // 设定鼠标事件为左键按下
        SendInput(1, &input, sizeof(INPUT));  // 使用SendInput函数发送鼠标事件
        // 设置鼠标被按下
        mouse_flag.mouse_left_down = True;  // 标志为true
    }
    else if (button == "right")
    {
        // 如果没传参数默认左键
        INPUT input = {0};  // 定义INPUT结构体变量表示输入事件信息
        input.type = INPUT_MOUSE;  // 指定输入事件类型为鼠标事件
        input.mi.dwFlags = MOUSEEVENTF_RIGHTDOWN;  // 设定鼠标事件为左键按下
        SendInput(1, &input, sizeof(INPUT));  // 使用SendInput函数发送鼠标事件
        // 设置鼠标被按下
        mouse_flag.mouse_right_down = True;
    }
}

void MouseEvent::MouseUp(const string& button="left")
{
    if  (button == "left")
    {
        INPUT input = {0};
        input.type = INPUT_MOUSE;
        input.mi.dwFlags = MOUSEEVENTF_LEFTUP; // 假设是左键，根据需要调整
        SendInput(1, &input, sizeof(INPUT));
        // 松开标志为False
        mouse_flag.mouse_left_down = False;
    }
    else if (button == "right")
    {
        INPUT input = {0};
        input.type = INPUT_MOUSE;
        input.mi.dwFlags = MOUSEEVENTF_RIGHTUP; // 假设是左键，根据需要调整
        SendInput(1, &input, sizeof(INPUT));
        // 松开标志为False
        mouse_flag.mouse_right_down = False;
    }
}

void MouseEvent::MouseRoll(int move)
{
    INPUT input = {0};
    input.type = INPUT_MOUSE;
    input.mi.dx = 0;       // x坐标
    input.mi.dy = 0;       // y坐标
    input.mi.mouseData = move; // 滚动方向和距离
    input.mi.dwFlags = MOUSEEVENTF_WHEEL; // 发送滚轮事件
    input.mi.time = 0;     // 当前系统时间
    input.mi.dwExtraInfo = 0; // 额外信息

    SendInput(1, &input, sizeof(INPUT));
}

//              鼠标事件监听             //

// 定义全局变量，用于存储鼠标钩子句柄
HHOOK hMouseHook = NULL;

// 钩子回调函数，用于处理鼠标事件 //
LRESULT CALLBACK MouseProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    // 获取鼠标事件的详细信息
    MSLLHOOKSTRUCT* pMouseStruct = (MSLLHOOKSTRUCT*)lParam;

    // 如果钩子代码有效（nCode >= 0），处理鼠标事件
    if (nCode >= 0)
    {
        if (mouseEventProcessed.load())
        {
            // 结尾需要把 mouseEventProcessed 改为false //
            // 把鼠标事件码赋值给全局变量 //
            MOUSE_CODE = wParam;

            // 根据wParam判断鼠标事件类型
            switch (wParam)
            {
                case WM_LBUTTONDOWN: // 左键按下
//                std::cout << "Mouse left button down at (" << pMouseStruct->pt.x << ", " << pMouseStruct->pt.y << ")" << std::endl;
                    MOUSE_CODE = wParam;
                    break;

                case WM_LBUTTONUP: // 左键释放
//                std::cout << "Mouse left button up at (" << pMouseStruct->pt.x << ", " << pMouseStruct->pt.y << ")" << std::endl;
                    MOUSE_CODE = wParam;
                    break;

                case WM_RBUTTONDOWN: // 右键按下
//                std::cout << "Mouse right button down at (" << pMouseStruct->pt.x << ", " << pMouseStruct->pt.y << ")" << std::endl;
                    MOUSE_CODE = wParam;
                    break;

                case WM_RBUTTONUP: // 右键释放
//                std::cout << "Mouse right button up at (" << pMouseStruct->pt.x << ", " << pMouseStruct->pt.y << ")" << std::endl;
                    MOUSE_CODE = wParam;
                    break;

                case WM_MBUTTONDOWN: // 中键按下
//                std::cout << "Mouse middle button down at (" << pMouseStruct->pt.x << ", " << pMouseStruct->pt.y << ")" << std::endl;
                    MOUSE_CODE = wParam;
                    break;

                case WM_MBUTTONUP: // 中键释放
//                std::cout << "Mouse middle button up at (" << pMouseStruct->pt.x << ", " << pMouseStruct->pt.y << ")" << std::endl;
                    MOUSE_CODE = wParam;
                    break;

            }

            // 监听鼠标侧边按钮 //
            if (nCode == HC_ACTION)
            {
                auto* pMouse = reinterpret_cast<MSLLHOOKSTRUCT*>(lParam);

                // 侧边按钮按下 //
                if (wParam == WM_XBUTTONDOWN)
                {
                    // 检查侧键（高16位）
                    DWORD button = HIWORD(pMouse->mouseData);

                    // 后退按钮(按下) //
                    if (button == XBUTTON1)
                    {
                        MOUSE_CODE = XBUTTON1DOWN;
//                        std::cout << "[全局钩子] 侧键 1 按下" << std::endl;
                    }
                        // 前进按钮(按下) //
                    else if (button == XBUTTON2)
                    {
                        MOUSE_CODE = XBUTTON2DOWN;
//                        std::cout << "[全局钩子] 侧键 2 按下" << std::endl;
                    }
                }

                // 侧边按钮抬起 //
                if (wParam == WM_XBUTTONUP)
                {
                    // 检查侧键（高16位）
                    DWORD button = HIWORD(pMouse->mouseData);

                    // 后退按钮(抬起) //
                    if (button == XBUTTON1)
                    {
                        MOUSE_CODE = XBUTTON1UP;
//                        std::cout << "[全局钩子] 侧键 1 抬起" << std::endl;
                    }
                        // 前进按钮(抬起) //
                    else if (button == XBUTTON2)
                    {
                        MOUSE_CODE = XBUTTON2UP;
//                        std::cout << "[全局钩子] 侧键 2 抬起" << std::endl;
                    }
                }
            }

            // 标记有新事件待处理 //
            mouseEventProcessed.store(false);
        }
    }


    // 调用下一个钩子，确保其他程序也能正常处理鼠标事件
    return CallNextHookEx(NULL, nCode, wParam, lParam);
}

// 共有函数，获取鼠标事件码 //
int MouseEvent::GetMouseCode()
{
    // 检查是否有未处理事件 //
    if (!mouseEventProcessed.load())  // 检查是否有未处理事件
    {
        // 标记事件已处理 //
        mouseEventProcessed.store(true);

        switch (MOUSE_CODE)
        {
            case WM_LBUTTONDOWN: // 左键按下
                return WM_LEFTDOWN;

            case WM_LBUTTONUP: // 左键释放
                return WM_LEFTUP;

            case WM_RBUTTONDOWN: // 右键按下
                return WM_RIGHTDOWN;

            case WM_RBUTTONUP: // 右键释放
                return WM_RIGHTUP;

            case WM_MBUTTONDOWN: // 中键按下
                return WM_ROLLDOWN;

            case WM_MBUTTONUP: // 中键释放
                return WM_ROLLUP;

            // 鼠标侧边按钮 //
            case XBUTTON2DOWN:  // 前进按下(按钮1):  // 前进按下(按钮2)
                return WM_FORWARDOWN;
//
            case XBUTTON1DOWN:  // 后退按下(按钮1)
                return WM_BACKSPACEDOWN;

            // 侧边抬起 //
            case XBUTTON2UP:  // 前进抬起(按钮2)
                return WM_FORWARDUP;
            case XBUTTON1UP:  // 后退抬起(按钮1)
                return WM_BACKSPACEUP;
        }
    }
    return 0;
}

// 监听鼠标函数 //
void MouseEvent::ListenMouseEvent()
{
    // 安装鼠标钩子，并将句柄存储到全局变量中
    hMouseHook = SetWindowsHookEx(WH_MOUSE_LL, MouseProc, GetModuleHandle(nullptr), 0);

    // 检查安装钩子是否成功 //
    if (hMouseHook == nullptr)
    {
        std::cerr << "Failed to install mouse hook." << std::endl;
        return ; // 如果安装钩子失败，退出程序
    }

    // 当 PostQuitMessage(0) 被调用时，GetMessage会返回 0, 从而退出循环。 //
    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0) > 0) // 使用GetMessage返回值判断是否收到退出消息
    {
        TranslateMessage(&msg); // 翻译消息
        DispatchMessage(&msg); // 派发消息
    }
}

// 退出函数，用于清理资源并退出程序
void MouseEvent::ExitMouseEvent()
{
    // 检查全局变量hMouseHook是否有效
    if (hMouseHook != nullptr)
    {
        // 移除鼠标钩子
        UnhookWindowsHookEx(hMouseHook);
        hMouseHook = nullptr; // 将全局变量置为空
    }

    // 发送程序结束消息 //
    PostQuitMessage(0);

    exit(0); // 退出程序
}

void MouseEvent::UninstallMouseEvent()
{
    // 检查全局变量hMouseHook是否有效
    if (hMouseHook != nullptr)
    {
        // 移除鼠标钩子
        UnhookWindowsHookEx(hMouseHook);
        hMouseHook = nullptr; // 将全局变量置为空
    }
}


/************************* 键盘事件 ****************************/
// 键盘按下记录方便后期查询是否释放 //
void key_down_record(int key_code)  // 记录键盘按下 (避免重复)
{
    int len = sizeof(free_keys.key_code) / sizeof(free_keys.key_code[0]);  // 检查按键数组大小
    bool found = false;  // 标记是否找到按键码

    // 遍历数组，检查按键码是否已经存在
    for (int i = 0; i < len; i++)
    {
        if (free_keys.key_code[i] == key_code)
        {
            found = true;  // 找到按键码，设置标记为true
            break;
        }
    }

    // 如果没有找到按键码，添加到数组的第一个空位置
    if (!found)  // 如果没找到 就重新遍历数组 寻找值为0的位置 将虚键码赋值在上面
    {
        for (int i = 0; i < len; i++)
        {
            if (free_keys.key_code[i] == 0)  // 找到数组的第一个空位置 (找到数组为0的位置，将虚键码赋值到上面)
            {
                free_keys.key_code[i] = key_code;
                break;
            }
        }
    }
}

// 记录键盘松开，清空按键 //
void key_up_record(int key_code)
{
    int len = sizeof(free_keys.key_code) / sizeof(free_keys.key_code[0]);  // 检查释放键盘的数组大小
    for (int i = 0; i < len; i++)
    {
        if (free_keys.key_code[i] == key_code)
        {
            free_keys.key_code[i] = 0;  // 清空按键码
            break;
        }
    }
}

// 键盘按下 //
void KeyBoardEvent::KeyDown(const string& key)
{
    /****************列表长度************************/
    int alphabet_list_len = sizeof (alphabet_list)/sizeof (alphabet_list[0]);  // 字母数字长度
    int function_keys_list_len = sizeof (function_keys_list)/sizeof (function_keys_list[0]);  // 功能键数组长度

    string key_upper = key;
    transform(key_upper.begin(), key_upper.end(), key_upper.begin(), ::tolower);

    for (int i = 0; i<alphabet_list_len; i++)
    {
        // 检查数组的字符是否与传入的参数一样(判断字母) 如果都没进入下一个循环
        if (key_upper == alphabet_list[i])
        {
            INPUT input; // 声明一个 INPUT 结构体变量 input，用于描述按键事件

            input.type = INPUT_KEYBOARD; // 指定 input 的类型为键盘输入
            input.ki.wScan = 0; // 扫描码置为 0，通常不需要使用
            input.ki.time = 0; // 时间戳置为 0
            input.ki.dwExtraInfo = 0; // 额外信息置为 0

            // 模拟按下目标键
            input.ki.wVk = alphabet_code[i]; // 指定模拟按下的键为 目标 键
            input.ki.dwFlags = 0; // 指定键盘按下事件，dwFlags 为 0
            SendInput(1, &input, sizeof(INPUT)); // 发送按键事件给系统

            key_down_record(alphabet_code[i]);
            break;
        }
    }

    for (int i=0; i<function_keys_list_len; i++)
    {
        // 是否与传入的参数一样 (判断功能键)
        if (key_upper == function_keys_list[i])
        {
            INPUT input; // 声明一个 INPUT 结构体变量 input，用于描述按键事件

            input.type = INPUT_KEYBOARD; // 指定 input 的类型为键盘输入
            input.ki.wScan = 0; // 扫描码置为 0，通常不需要使用
            input.ki.time = 0; // 时间戳置为 0
            input.ki.dwExtraInfo = 0; // 额外信息置为 0

            // 模拟按下目标键
            input.ki.wVk = function_code[i]; // 指定模拟按下的键为 目标 键
            input.ki.dwFlags = 0; // 指定键盘按下事件，dwFlags 为 0
            SendInput(1, &input, sizeof(INPUT)); // 发送按键事件给系统

            key_down_record(function_code[i]);
            break;
        }
    }
}

// 键盘释放 //
void KeyBoardEvent::KeyUp(const string& key)
{
    int len = sizeof (free_keys.key_code)/sizeof (free_keys.key_code[0]);
/****************列表长度************************/
    int alphabet_list_len = sizeof (alphabet_list)/sizeof (alphabet_list[0]);  // 字母数字长度
    int function_keys_list_len = sizeof (function_keys_list)/sizeof (function_keys_list[0]);  // 功能键数组长度

    string key_upper = key;
    transform(key_upper.begin(), key_upper.end(), key_upper.begin(), ::tolower);

    for (int i = 0; i<alphabet_list_len; i++) {
        // 检查数组的字符是否与传入的参数一样(判断字母) 如果都没进入下一个循环
        if (key_upper == alphabet_list[i]) {
            INPUT input = {0};
            input.type = INPUT_KEYBOARD;
            input.ki.wVk = alphabet_code[i];  // 键位吗码
            // 如果之前按键被按下了，现在需要释放
            input.ki.dwFlags = KEYEVENTF_KEYUP;
            SendInput(1, &input, sizeof(INPUT));

            key_up_record(alphabet_code[i]);
            break;
        }
    }


    for (int i=0; i<function_keys_list_len; i++)
    {
        // 是否与传入的参数一样 (判断功能键)
        if (key_upper == function_keys_list[i])
        {
            INPUT input = {0};
            input.type = INPUT_KEYBOARD;
            input.ki.wVk = function_code[i];  // 键位吗码
            // 如果之前按键被按下了，现在需要释放
            input.ki.dwFlags = KEYEVENTF_KEYUP;
            SendInput(1, &input, sizeof(INPUT));

            key_up_record(function_code[i]);
            break;
        }
    }

//    INPUT input = {0};
//    input.type = INPUT_KEYBOARD;
//    input.ki.wVk = vkCode;  // 键位吗码
//    // 如果之前按键被按下了，现在需要释放
//    input.ki.dwFlags = KEYEVENTF_KEYUP;
//    SendInput(1, &input, sizeof(INPUT));
}

// 键盘点击 //
void KeyBoardEvent::PressKey(const std::string &key)
{
    KeyDown(key);
    KeyUp(key);
}

/**
 *                    _ooOoo_
 *                   o8888888o
 *                   88" . "88
 *                   (| -_- |)
 *                    O\ = /O
 *                ____/`---'\____
 *              .   ' \\| |// `.
 *               / \\||| : |||// \
 *             / _||||| -:- |||||- \
 *               | | \\\ - /// | |
 *             | \_| ''\---/'' | |
 *              \ .-\__ `-` ___/-. /
 *           ___`. .' /--.--\ `. . __
 *        ."" '< `.___\_<|>_/___.' >'"".
 *       | | : `- \`.;`\ _ /`;.`/ - ` : | |
 *         \ \ `-. \_ __\ /__ _/ .-` / /
 * ======`-.____`-.___\_____/___.-`____.-'======
 *                    `=---='
 *
 * .............................................
 *          佛祖保佑             永无BUG
 **/

// 模拟输入文字 //
void KeyBoardEvent::WriteStr(string output)
{
    // 检查是否没有按下shift键 //
    bool shift_up = false;
    /****************列表长度************************/
    int alphabet_list_len = sizeof (alphabet_list)/sizeof (alphabet_list[0]);  // 字母数字长度
    int symbol_not_shift_len = sizeof (symbol_list_not_shift_press)/sizeof(symbol_list_not_shift_press[0]); // 字符长度
    int symbol_need_shift_len = sizeof (symbol_list_need_shift_press)/sizeof (symbol_list_need_shift_press[0]); // 字符数组长度

    /****************************** 执行部分 ************************************/
    // 循环遍历输入字符串中的每一个字符
    for (auto i:output)
    {
        char current_char = i;  // 将字符存储到字符变量

        // 处理字母
        for (int alp = 0; alp < alphabet_list_len; alp++)
        {
            // 检查是否为小写字母
            if (tolower(current_char) == alphabet_list[alp][0])
            {
                // 检查是否为大写字母
                bool is_uppercase = isupper(current_char); // 如果是大写

                if (is_uppercase)  // 如果有大写字母
                {
                    INPUT inputs[2] = {0};  // 设置两个按键
                    // 如果是大写字母，则首先模拟按下 Shift 键
                    inputs[0].type = INPUT_KEYBOARD;
                    inputs[0].ki.wVk = VK_SHIFT; // 'shift'键的虚拟键码
                    inputs[0].ki.dwFlags = 0; // 表示按下按键

                    // 模拟按下目标键
                    inputs[1].type = INPUT_KEYBOARD;
                    inputs[1].ki.wVk = alphabet_code[alp]; // 目标键的虚拟键码
                    inputs[1].ki.dwFlags = 0; // 表示按下按键
                    SendInput(2, inputs, sizeof(INPUT));  // 发送按键事件给系统
                    shift_up = true;  // shift被按下

                    // 释放 Shift 键和目标键
                    inputs[0].ki.dwFlags = KEYEVENTF_KEYUP; // 表示按键释放
                    inputs[1].ki.dwFlags = KEYEVENTF_KEYUP; // 表示按键释放
                    SendInput(2, inputs, sizeof(INPUT));  // 再次发送按键事件给系统
                    shift_up = false;  // shift被释放
                }
                else
                {
                    // 如果是小写字母，则直接模拟按下目标键
                    INPUT input; // 声明一个 INPUT 结构体变量 input，用于描述按键事件

                    input.type = INPUT_KEYBOARD;
                    input.ki.wScan = 0; // 扫描码置为 0，通常不需要使用
                    input.ki.time = 0; // 时间戳置为 0
                    input.ki.dwExtraInfo = 0; // 额外信息置为 0

                    // 模拟按下目标键
                    input.ki.wVk = alphabet_code[alp]; // 指定模拟按下的键为 目标 键
                    input.ki.dwFlags = 0; // 指定键盘按下事件，dwFlags 为 0
                    SendInput(1, &input, sizeof(INPUT)); // 发送按键事件给系统
                    shift_up = true;  // shift被按下

                    // 模拟释放目标键
                    input.ki.dwFlags = KEYEVENTF_KEYUP; // 指定键盘释放事件，dwFlags 设置为 KEYEVENTF_KEYUP
                    SendInput(1, &input, sizeof(INPUT)); // 再次发送按键事件给系统
                    shift_up = false;  // shift被释放
                }
                break;
            }
        }


        for (int syb_no_shift=0; syb_no_shift< symbol_not_shift_len; syb_no_shift++)
        {
            // 是否与传入的参数一样 (判断无需按shift按键的符号)
            if (current_char == symbol_list_not_shift_press[syb_no_shift][0])  // 取出当前字符与中的字符与参数传入的字符进行比较
            {
                INPUT input; // 声明一个 INPUT 结构体变量 input，用于描述按键事件

                input.type = INPUT_KEYBOARD; // 指定 input 的类型为键盘输入
                input.ki.wScan = 0; // 扫描码置为 0，通常不需要使用
                input.ki.time = 0; // 时间戳置为 0
                input.ki.dwExtraInfo = 0; // 额外信息置为 0

                // 模拟按下目标键
                input.ki.wVk = symbol_not_shift_code[syb_no_shift]; // 指定模拟按下的键为 目标 键
                input.ki.dwFlags = 0; // 指定键盘按下事件，dwFlags 为 0
                SendInput(1, &input, sizeof(INPUT)); // 发送按键事件给系统
                shift_up = true;  // shift被按下

                input.ki.wVk = symbol_not_shift_code[syb_no_shift]; // 指定模拟释放的键仍然是 目标 键
                input.ki.dwFlags = KEYEVENTF_KEYUP; // 指定键盘释放事件，dwFlags 设置为 KEYEVENTF_KEYUP
                SendInput(1, &input, sizeof(INPUT)); // 再次发送按键事件给系统
                shift_up = false;  // shift被释放
                break;
            }
            // 处理空格
            if (current_char == ' ')
            {
                // 模拟按下空格键
                INPUT input; // 声明一个 INPUT 结构体变量 input，用于描述按键事件

                input.type = INPUT_KEYBOARD;
                input.ki.wScan = 0; // 扫描码置为 0，通常不需要使用
                input.ki.time = 0; // 时间戳置为 0
                input.ki.dwExtraInfo = 0; // 额外信息置为 0


                input.ki.wVk = VK_SPACE; // 指定模拟按下的键为 空格 键
                input.ki.dwFlags = 0; // 指定键盘按下事件，dwFlags 为 0
                SendInput(1, &input, sizeof(INPUT)); // 发送按键事件给系统
                shift_up = true;  // shift被按下

                // 模拟释放空格键
                input.ki.dwFlags = KEYEVENTF_KEYUP; // 指定键盘释放事件，dwFlags 设置为 KEYEVENTF_KEYUP
                SendInput(1, &input, sizeof(INPUT)); // 再次发送按键事件给系统
                shift_up = false;  // shift被释放
                break;
            }
        }

        for (int syb_need_shift=0; syb_need_shift< symbol_need_shift_len; syb_need_shift++)
        {
            // 是否与传入的参数一样 (判断需按shift按键的符号功能)
            if (current_char == symbol_list_need_shift_press[syb_need_shift][0])  // 取出当前字符与中的字符与参数传入的字符进行比较
            {
                // 创建两个输入结构体并初始化
                INPUT inputs[2] = {0};

                // 第一个按键 'shift' 的输入结构体
                inputs[0].type = INPUT_KEYBOARD;
                inputs[0].ki.wVk = VK_SHIFT; // 'shift'键的虚拟键码
                inputs[0].ki.dwFlags = 0; // 表示按下按键

                // 第二个按键 '目标参数' 的输入结构体
                inputs[1].type = INPUT_KEYBOARD;
                inputs[1].ki.wVk = symbol_need_shift_code[syb_need_shift]; // '目标参数'键的虚拟键码
                inputs[1].ki.dwFlags = 0; // 表示按下按键
                SendInput(2, inputs, sizeof (INPUT));  // 发生指令按下shift与参数按键
                shift_up = true;  // shift被按下

                inputs[0].ki.dwFlags = KEYEVENTF_KEYUP; // 表示按键释放
                inputs[1].ki.dwFlags = KEYEVENTF_KEYUP; // 表示按键释放
                SendInput(2, inputs, sizeof(INPUT));  // 同时释放
                shift_up = false;  // shift被释放
                break;
            }
        }
    }
    if (!shift_up)
    {
        // 定义INPUT结构体
        INPUT input_shift = {0};
        input_shift.type = INPUT_KEYBOARD;  // 指定输入类型为键盘

        // 模拟释放Shift键
        input_shift.ki.wVk = VK_SHIFT;       // 设置虚拟键码为Shift
        input_shift.ki.dwFlags = KEYEVENTF_KEYUP;  // 指定键盘释放事件

        // 发送键盘释放事件
        SendInput(1, &input_shift, sizeof(INPUT));
    }
}
/*********** 剪切板******************/
// 字符串拷贝辅助哈纳斯 //
void copy_str_in(copy_str_structs self)  // 复制到剪切板的函数，后续包裹在CopyStr函数中
{
    if (OpenClipboard(NULL))
    {
        // 清空剪切板内容
        EmptyClipboard();

        // 分配内存并将文本内容复制到全局内存块
        HGLOBAL hglbCopy = GlobalAlloc(GMEM_MOVEABLE, strlen(self.textToCopy) + 1); // +1是为了包含字符串的结尾 null 字符
        LPVOID lpCopy = NULL;
        if (hglbCopy!= NULL)
        {
            lpCopy = GlobalLock(hglbCopy);
            strcpy((char*)lpCopy, self.textToCopy);
            GlobalUnlock(hglbCopy);

            // 将全局内存块设置为剪切板内容
            SetClipboardData(CF_TEXT, hglbCopy);
        }
        else
        {
            // 如果hglbCopy分配失败，检查lpCopy是否已经被获取并释放
            if (lpCopy!= NULL)
            {
                GlobalFree(lpCopy);
            }
        }

        // 关闭剪切板
        CloseClipboard();
    }
}

// 赋值到剪切板 //
void KeyBoardEvent::CopyStr(const char *str)
{
    // 复制字符窜到剪切板
    copy_str_structs self = {str, copy_str_in};
    self.copy_str_in(self);
}

/*************** 注册快捷键部分 ******************/
// 定义全局变量来保存钩子句柄 //
HHOOK hHook = nullptr;  // HHOOK 类型用于保存钩子句柄;

// 获取单个按键虚键码并返回 //
int getOneKeyCode(string key_name)
{
    // 初始化索引值为第一个 //
    int index = 0;

    // 变量字母的列表，查找虚键码 //
    for (auto i:alphabet_list)
    {
        // 如果与传入的字符串相等，截取索引值获得虚键码并返回，反之索引增加 //
        if (key_name == i)
        {
//            cout<<"index in :alphabet_list"<<index<<endl;
            return alphabet_code[index];
        }
        index++;
    }

    // 如果第一轮没有找到，归零索引重新在功能名称找对应虚键码 //
    index = 0;

    // 变量字母的列表，查找虚键码 //
    for (auto i:function_keys_list)
    {
        // 如果与传入的字符串相等，截取索引值获得虚键码并返回，反之索引增加 //
        if (key_name == i)
        {
//            cout<<"index int function_keys_list:"<<index<<endl;
            return function_code[index];
        }
        index++;
    }

    // 如果都找不到说明快捷键注册不合法，返回-1 //
    cout<<"The shortcut name does not exist. Make sure to register a valid shortcut\n";
    return  -1;
}

// 键盘钩子的回调函数
LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    for (auto hotKeys:key_code)
    {
        // 检查钩子操作是否成功 //
        if (nCode >= 0)
        {
            // 获取键盘钩子结构体 //
            PKBDLLHOOKSTRUCT pKey = (PKBDLLHOOKSTRUCT)lParam;

//            // 先检查是否有单个快捷键是特殊按键注册 //
//            if (hotKeys.FuncID == 1 && hotKeys.key1 != 0)
//            {
////                printf("键码为: %d\n ctrl虚键码: %d\n", hotKeys.key1, VK_CONTROL);
//                // 检查是否为键盘按下消息，且同时按下注册的快捷键
//                if ((GetAsyncKeyState(hotKeys.key1) & 0x8000))               // 检查第二个键是否按下
//                {
//                    // 回调注册的函数
//                    oneKeyFunc[hotKeys.FuncIndex]();
//                    return CallNextHookEx(nullptr, nCode, wParam, lParam);
//                }
//            }

            // 先注册单个快捷键.并且确保快捷键虚键码有效，ID确保快捷键数量一样，比如单快捷键[a]，双快捷键等待[ctrl+a] //
            if (hotKeys.FuncID==1 &&hotKeys.key1 !=0)
            {
                // 监听键盘按下事件，监听热键结构体列表的key1
                if (wParam == WM_KEYDOWN &&pKey->vkCode == hotKeys.key1)
                {
                    // 回调注册的函数  //
                    oneKeyFunc[hotKeys.FuncIndex]();
//                    cout<<"注册单个快捷键:"<<hotKeys.key1<<" 函数索引为:"<<hotKeys.FuncIndex<<"ID:"<<hotKeys.FuncID<<endl;
                    return CallNextHookEx(nullptr, nCode, wParam, lParam);
                }
            }

                // 双快捷键注册,查询双快捷键结构体的虚键码是否都不为0 //
            else if (hotKeys.FuncID == 2 && hotKeys.key1 != 0 && hotKeys.key2 != 0)
            {
                // 检查是否为键盘按下消息，且同时按下注册的快捷键
                if ((wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN) &&  // 监听按键按下,(wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN) 优先级判断
                    (GetAsyncKeyState(hotKeys.key1) & 0x8000) &&  // 检查修饰键（如Ctrl或Alt）是否按下
                    (pKey->vkCode == hotKeys.key2))               // 检查第二个键是否按下
                {
                    // 回调注册的函数
                    twoKeyFunc[hotKeys.FuncIndex]();
                    return CallNextHookEx(nullptr, nCode, wParam, lParam);
                }
            }

                // 三快捷键注册,查询三快捷键结构体的虚键码是否都不为0 //
            else if (hotKeys.FuncID == 3 && hotKeys.key1 != 0 && hotKeys.key2 != 0 && hotKeys.key3 != 0)
            {
                // 获取键盘钩子结构体
                PKBDLLHOOKSTRUCT pKey = (PKBDLLHOOKSTRUCT)lParam;

                // 检查是否为键盘按下消息，且同时按下注册的快捷键
                if ((wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN) &&  // 监听按键按下
                    (GetAsyncKeyState(hotKeys.key1) & 0x8000) &&  // 检查修饰键1（如Ctrl）是否按下
                    (GetAsyncKeyState(hotKeys.key2) & 0x8000) &&  // 检查修饰键2（如Alt）是否按下
                    (pKey->vkCode == hotKeys.key3))               // 检查第三个键是否按下
                {
                    // 回调注册的函数
                    threeKeyFunc[hotKeys.FuncIndex]();
                    return CallNextHookEx(nullptr, nCode, wParam, lParam);
                }
            }

                // 四快捷键注册,查询四快捷键结构体的虚键码是否都不为0 //
            else if (hotKeys.FuncID == 4 && hotKeys.key1 != 0 && hotKeys.key2 != 0 && hotKeys.key3 != 0 && hotKeys.key4 != 0)
            {
//                printf("k1:%d key2:%d key3:%d key4:%d\n", hotKeys.key1, hotKeys.key2, hotKeys.key3, hotKeys.key4);
                // 获取键盘钩子结构体
                PKBDLLHOOKSTRUCT pKey = (PKBDLLHOOKSTRUCT)lParam;

                // 检查是否为键盘按下消息，且同时按下注册的快捷键
                if ((wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN) &&  // 监听按键按下
                    (GetAsyncKeyState(hotKeys.key1) & 0x8000) &&  // 检查修饰键1（如Ctrl）是否按下
                    (GetAsyncKeyState(hotKeys.key2) & 0x8000) &&  // 检查修饰键2（如Alt）是否按下
                    (GetAsyncKeyState(hotKeys.key3) & 0x8000) &&  // 检查修饰键3（如Shift）是否按下
                    (pKey->vkCode == hotKeys.key4))               // 检查第四个键是否按下
                {
                    // 回调注册的函数
                    fourKeyFunc[hotKeys.FuncIndex]();
                    return CallNextHookEx(nullptr, nCode, wParam, lParam);
                }
            }
        }
    }
    return CallNextHookEx(hHook, nCode, wParam, lParam);
}


// 监听快捷键使用wait hot key 回调KeyboardProc函数 //
void KeyBoardEvent::AddHotKey(const string &key, std::function<void()> targetVoidFunc)
{
    // 获取注册的快捷键名称 //
    std::regex wordRegex(R"((\w+)+)");
    // 创建一个正则表达式迭代器，用于在text字符串中搜索匹配wordRegex模式的子串。
    // text.begin()和text.end()定义了搜索的范围寻找快捷键名称。
    auto wordBegin = std::sregex_iterator(key.begin(), key.end(), wordRegex);

    // 创建一个结束迭代器，用于在搜索结束时作为迭代器的比较目标。
    auto wordEnd = std::sregex_iterator();

    // 临时存放虚键码的数组，每次循环开始就重新定义 //
    vector<int> keyCodeTemp;

    // 使用for循环遍历所有匹配的子串。
    for (std::sregex_iterator j = wordBegin; j != wordEnd; ++j)
    {
        // 获取当前迭代器指向的匹配结果。
        std::smatch match = *j;
        string hotKey = match.str();
        transform(hotKey.begin(), hotKey.end(), hotKey.begin(), ::tolower);
        // 输出匹配到的字母序列，使用match.str()获取匹配的字符串。
//        std::cout << "匹配到的字母序列：" << match.str() << std::endl;

        // 获取虚键码函数，将其推送到临时数组中 //
        keyCodeTemp.push_back(getOneKeyCode(hotKey));
    }
    // 获取数组长度，进行快捷键数组长度判断，并赋值虚键码 //
    int arrSize = keyCodeTemp.size();

    // 临时虚键码存放//
    int Ctrl = 0;
    int Alt = 0;
    int Shift = 0;
    int Other = 0;

    //  根据长度进行赋值虚键码，长度为1：case1：等等 //
    switch (arrSize)
    {
        // 给有虚键码赋值虚键码，无的赋值0 //
        case 1:KeyCode oneKey;
            oneKey.key1 = keyCodeTemp[0];
            oneKey.key2 = 0;
            oneKey.key3 = 0;
            oneKey.key4 = 0;

            oneKey.FuncIndex = oneKeyIndex;  // 赋值索引后索引值+1，调用注册函数采用先注册的顺序
            oneKey.FuncID = 1;  // 代表只有一个按键注册
            key_code.push_back(oneKey);  // 添加快捷键结构体到数组
            oneKeyFunc.push_back(targetVoidFunc);  // 单快捷键数组增加快捷键函数
            oneKeyIndex++;  // ID自增
            if (keyCodeTemp[0] == VK_CONTROL)
            {
                printf("ctrl %d\n", keyCodeTemp[0]);
            }
            if (keyCodeTemp[0] == VK_SHIFT)
            {
                printf("shift %d\n", keyCodeTemp[0]);
            }
            if (keyCodeTemp[0] == VK_MENU)
            {
                printf("alt %d\n", keyCodeTemp[0]);
            }
            break;

            // 双快捷键 //
        case 2:KeyCode  twoKey;
            // 如果第二个快捷键为ctrl,alt,shift就纠正顺序 //
            if (keyCodeTemp[1] ==VK_CONTROL || keyCodeTemp[1] ==VK_SHIFT || keyCodeTemp[1] ==VK_MENU)
            {
                // 如果第一个不是ctrl等按键那么将后面的赋值给前面 //
                twoKey.key1 = keyCodeTemp[1];  // 确保第一个键是ctrl等按键
                twoKey.key2 = keyCodeTemp[0];
                twoKey.key3 = 0;
                twoKey.key4 = 0;

                twoKey.FuncIndex = twoKeyIndex;  // 赋值索引后索引值+1，调用注册函数采用先注册的顺序
                twoKey.FuncID = 2;  // 代表有两个按键注册
                key_code.push_back(twoKey);  // 添加快捷键结构体到数组
                twoKeyFunc.push_back(targetVoidFunc);  // 双快捷键数组增加快捷键函数
                twoKeyIndex++;  // ID自增
                break;
            }
            twoKey.key1 = keyCodeTemp[0];
            twoKey.key2 = keyCodeTemp[1];
            twoKey.key3 = 0;
            twoKey.key4 = 0;

            twoKey.FuncIndex = twoKeyIndex;  // 赋值索引后索引值+1，调用注册函数采用先注册的顺序
            twoKey.FuncID = 2;  // 代表有两个按键注册
            key_code.push_back(twoKey);  // 添加快捷键结构体到数组
            twoKeyFunc.push_back(targetVoidFunc);  // 双快捷键数组增加快捷键函数
            twoKeyIndex++;  // ID自增
            break;

            // 三快捷键 //
        case 3:KeyCode threeKey;
            // 遍历虚键码列表调整顺序 //
            for (const auto &i:keyCodeTemp)
            {
                switch (i)
                {
                    case VK_CONTROL:
                        Ctrl = i;
                        break;
                    case VK_SHIFT:
                        Shift = i;
                        break;
                    case VK_MENU:
                        Alt = i;
                        break;
                    default:
                        Other = i;
                        break;
                }
            }
            if (Ctrl !=0 && Alt !=0 && Shift ==0)
            {
                // 如果Ctrl，Alt被注册，Shift没有被注册，按照顺序来 //
                threeKey.key1 = Ctrl;
                threeKey.key2 = Alt;
                threeKey.key3 = Other;
                threeKey.key4 = 0;
            }
            else if (Ctrl !=0 && Shift !=0 && Alt ==0)
            {
                // 如果Ctrl，Shift被注册，Alt没有被注册，按照顺序来 //
                threeKey.key1 = Ctrl;
                threeKey.key2 = Shift;
                threeKey.key3 = Other;
                threeKey.key4 = 0;
            }
            else if (Alt !=0 && Shift !=0 && Ctrl ==0)
            {
                // 如果Alt，Shift被注册,Ctrl没有被注册，按照顺序来 //
                threeKey.key1 = Alt;
                threeKey.key2 = Shift;
                threeKey.key3 = Other;
                threeKey.key4 = 0;
            }
            threeKey.FuncIndex = threeKeyIndex;  // 赋值索引后索引值+1，调用注册函数采用先注册的顺序
            threeKey.FuncID = 3;  // 代表有三个按键注册
            key_code.push_back(threeKey);  // 添加快捷键结构体到数组
            threeKeyFunc.push_back(targetVoidFunc);  // 三快捷键数组增加快捷键函数
            threeKeyIndex++;  // ID自增
            break;

            // 四快捷键 //
        case 4:KeyCode fourKey;
            // 遍历虚键码列表调整顺序 //
            for (const auto &i:keyCodeTemp)
            {
                switch (i)
                {
                    case VK_CONTROL:
                        Ctrl = i;
                        break;
                    case VK_SHIFT:
                        Shift = i;
                        break;
                    case VK_MENU:
                        Alt = i;
                        break;
                    default:
                        Other = i;
                        break;
                }
            }
            printf("\n");

            if (Ctrl !=0 && Alt !=0 && Shift !=0)
            {
                // 如果Ctrl,Alt,Shift都被注册 //
                fourKey.key1 = Ctrl;
                fourKey.key2 = Alt;
                fourKey.key3 = Shift;
                fourKey.key4 = Other;
            }

            fourKey.FuncIndex = fourKeyIndex;  // 赋值索引后索引值+1，调用注册函数采用先注册的顺序
            fourKey.FuncID = 4; // 代表有四个按键注册
            key_code.push_back(fourKey);  // 添加快捷键结构体到数组
            fourKeyFunc.push_back(targetVoidFunc);  // 四快捷键数组增加快捷键函数
            fourKeyIndex++;  // ID自增
            break;

    }
}



// 等待快捷键 //
void KeyBoardEvent::WaitHotKey()
{
    // 如果已经注册那就删除重新注册 //
    if (hHook)
    {
        UninstallHotKeyEvent();
        hHook = nullptr;
    }

    // 监听快捷键循环函数
    hHook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyboardProc, GetModuleHandle(NULL), 0);  // 安装低级键盘钩子

    MSG msg;          // MSG 结构体用于存储从消息队列中获取的消息


    // 进入消息循环
    while (GetMessage(&msg, NULL, 0, 0))  // 从消息队列中获取消息
    {
        TranslateMessage(&msg);           // 将虚拟键码转换成字符
        DispatchMessage(&msg);            // 分发消息到窗口过程
    }
}


// 函数为 static ClearHotKey 类成员成员函数调用清理快捷键函数 //
void KeyBoardEvent::ClearHotKey()
{
    if (hHook != NULL || hHook!= nullptr)
    {
        // 确保钩子被卸载
        UnhookWindowsHookEx(hHook);       // 卸载钩子
        hHook = nullptr;  // 重置钩子句柄

        // 发送程序结束消息
        PostQuitMessage(0);
        exit(0);
    }
}

void KeyBoardEvent::UninstallHotKeyEvent()
{
    if (hHook != NULL || hHook!= nullptr)
    {
        // 确保钩子被卸载
        UnhookWindowsHookEx(hHook);       // 卸载钩子
        hHook = nullptr;  // 重置钩子句柄
    }
}

/****************** 单个按键监听部分 *******************/

// 监听键盘按下与抬起的虚拟键码  暂时无用  //
long long ListenOneKeyCodeArr[256] = {
        65, 66, 67, 68, 69, 70, 71, 72, 73, 74,
        75, 76, 77, 78, 79, 80, 81, 82,
        83, 84, 85, 86, 87, 88, 89, 90,
        48, 49, 50, 51, 52, 53, 54, 55, 56, 57,
        112, 113, 114, 115, 116, 117, 118, 119,
        120, 121, 122, 123, 27, 9, 13, 8, 32,
        127, 38, 40, 37, 39, 162, 164, 160, 20
};

// 定义一个监听键盘按下与抬起钩子句柄 //
HHOOK hOneKeyEvent = nullptr;  // 钩子句柄

std::vector<bool> keyStates(256, false); // 跟踪256个虚拟键的状态


// 实时获取按键 //
LRESULT CALLBACK OneKeEventRealTimeProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    if (nCode == HC_ACTION) {
        KBDLLHOOKSTRUCT* pKeyInfo = (KBDLLHOOKSTRUCT*)lParam;
        const int vkCode = pKeyInfo->vkCode;

        switch (wParam) {
            case WM_KEYDOWN:
            case WM_SYSKEYDOWN:
                ONE_KEY_CODES.ONE_KEY_CODE = vkCode; // 按下时返回正数
                break;
            case WM_KEYUP:
            case WM_SYSKEYUP:
                ONE_KEY_CODES.ONE_KEY_CODE = -vkCode; // 抬起时返回负数
                break;
        }
        OneKeyEventProcessed.store(false);
    }
    return CallNextHookEx(nullptr, nCode, wParam, lParam);
}


// 不实时返回虚假码 //
LRESULT CALLBACK OneKeEventProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    if (nCode == HC_ACTION) {
        KBDLLHOOKSTRUCT* pKeyInfo = (KBDLLHOOKSTRUCT*)lParam;
        const int vkCode = pKeyInfo->vkCode;

        switch (wParam) {
            case WM_KEYDOWN:
            case WM_SYSKEYDOWN:
                if (!keyStates[vkCode])
                {
                    ONE_KEY_CODES.ONE_KEY_CODE = vkCode; // 按下时返回正数
                    keyStates[vkCode] = true;
                }
                break;
            case WM_KEYUP:
            case WM_SYSKEYUP:
                if (keyStates[vkCode])
                {
                    ONE_KEY_CODES.ONE_KEY_CODE = -vkCode; // 抬起时返回负数
                    keyStates[vkCode] = false;
                }
                break;
        }
        OneKeyEventProcessed.store(false);
    }
    return CallNextHookEx(nullptr, nCode, wParam, lParam);
}

// 监听单个快捷键事件 //
void KeyBoardEvent::ListenOneKeyEvent(bool real_time)
{
    StringCode scd;
    // 如果已经注册，注销重新注册 //
    if (hOneKeyEvent)
    {
        UninstallOneKeyEvent();
        hOneKeyEvent = nullptr;
    }

    // 判断是否需要实时监听 //
    if (real_time)
    {
        ONE_KEY_CODES.real_time = real_time;

        // 设置低级键盘钩子 实时监听//
        hOneKeyEvent = SetWindowsHookEx(WH_KEYBOARD_LL, OneKeEventRealTimeProc, GetModuleHandle(NULL), 0);

        if (hOneKeyEvent == nullptr) {
            std::cerr << scd.Utf8ToGBK("钩子安装失败! 错误代码: ") << GetLastError() << std::endl;
            return;
        }

        // 消息循环（必须存在以确保钩子正常工作）
        MSG msg;
        while (GetMessage(&msg, NULL, 0, 0)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
    else
    {
        ONE_KEY_CODES.real_time = real_time;

        // 设置低级键盘钩子 非实时监听//
        hOneKeyEvent = SetWindowsHookEx(WH_KEYBOARD_LL, OneKeEventRealTimeProc, GetModuleHandle(NULL), 0);


        if (hOneKeyEvent == nullptr)
        {
            std::cerr << "钩子安装失败! 错误代码: " << GetLastError() << std::endl;
            return;
        }

        // 消息循环（必须存在以确保钩子正常工作）
        MSG msg;
        while (GetMessage(&msg, NULL, 0, 0))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
}
// 默认不实时返回按键码仅在变化时候反馈 //
void KeyBoardEvent::ListenOneKeyEvent()
{
    ONE_KEY_CODES.real_time = false;
    StringCode scd;

    // 如果已经注册，注销重新注册 //
    if (hOneKeyEvent)
    {
        UninstallOneKeyEvent();
        hOneKeyEvent = nullptr;
    }

    // 设置低级键盘钩子 非实时监听//
    // 设置低级键盘钩子
    hOneKeyEvent = SetWindowsHookEx(WH_KEYBOARD_LL, OneKeEventProc, GetModuleHandle(NULL), 0);

    if (hOneKeyEvent == nullptr)
    {
        std::cerr << scd.Utf8ToGBK("钩子安装失败! 错误代码: " )<< GetLastError() << std::endl;
        return;
    }

    // 消息循环（必须存在以确保钩子正常工作）
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
}

//long KeyBoardEvent::GetOneKeyCode()
//{
//    static long lastCode = 0;
//    long currentCode = ONE_KEY_CODE;
//    lastCode = currentCode;
//    if (lastCode <=0)
//    {
//        return 0;
//    }
//    GetOneKeyCode();
//    return currentCode;
//}

long KeyBoardEvent::GetOneKeyCode()
{
    if (ONE_KEY_CODES.real_time)
    {
        if (!OneKeyEventProcessed.load())
        {
            OneKeyEventProcessed.store(true);
            long currentCode = ONE_KEY_CODES.ONE_KEY_CODE;
            ONE_KEY_CODES.ONE_KEY_CODE = 0; // 重置为0，避免重复处理
            return currentCode;
        }
    }
    else
    {
        if (!OneKeyEventProcessed.load())
        {
            OneKeyEventProcessed.store(true);
            long currentCode = ONE_KEY_CODES.ONE_KEY_CODE;
            ONE_KEY_CODES.ONE_KEY_CODE = 0; // 重置为0，避免重复处理
            return currentCode;
        }
    }
    return 0;
}

// 退出单个按键事件箭头 //
void KeyBoardEvent::ExitOneKeyEvent()
{
    if (hOneKeyEvent != NULL || hOneKeyEvent!= nullptr)
    {
        // 确保钩子被卸载
        UnhookWindowsHookEx(hOneKeyEvent);       // 卸载钩子
        hOneKeyEvent = nullptr;  // 重置钩子句柄
        // 发送程序结束消息 //
        PostQuitMessage(0);
        exit(0); // 退出程序
    }
}


// 注销事件但是不退出程序 //
void KeyBoardEvent::UninstallOneKeyEvent()
{
    if (hOneKeyEvent != NULL || hOneKeyEvent!= nullptr)
    {
        // 确保钩子被卸载
        UnhookWindowsHookEx(hOneKeyEvent);       // 卸载钩子
        hOneKeyEvent = nullptr;  // 重置钩子句柄
    }
}


/*************** 编码转化 ******************/

// 将字符串编码从UTF8转为GBK编码 //
//string StringCode::GBKToUTF8(const std::string &gbkStr)
//{
//    // 获取宽字符所需的长度
//    int wideCharLen = MultiByteToWideChar(CP_ACP, 0, gbkStr.c_str(), -1, nullptr, 0);
//    if (wideCharLen <= 0) {
//        return ""; // 转换失败
//    }
//
//    // 分配宽字符缓冲区
//    std::wstring wideStr;
//    wideStr.resize(wideCharLen);
//
//    // 将GBK字符串转换为宽字符
//    MultiByteToWideChar(CP_ACP, 0, gbkStr.c_str(), -1, &wideStr[0], wideCharLen);
//
//    // 获取UTF-8字符串所需的长度
//    int utf8Len = WideCharToMultiByte(CP_UTF8, 0, wideStr.c_str(), -1, nullptr, 0, nullptr, nullptr);
//    if (utf8Len <= 0) {
//        return ""; // 转换失败
//    }
//
//    // 分配UTF-8字符串缓冲区
//    std::string utf8Str;
//    utf8Str.resize(utf8Len);
//
//    // 将宽字符转换为UTF-8字符串
//    WideCharToMultiByte(CP_UTF8, 0, wideStr.c_str(), -1, &utf8Str[0], utf8Len, nullptr, nullptr);
//
//    return utf8Str;
//}

string StringCode::GBKToUTF8(const std::string &gbkStr)
{
    int wlen = MultiByteToWideChar(CP_ACP, 0, gbkStr.c_str(), -1, nullptr, 0);
    if (wlen <= 0) return "";

    std::wstring wstr(wlen, L'\0');
    MultiByteToWideChar(CP_ACP, 0, gbkStr.c_str(), -1, &wstr[0], wlen);

    // 宽字符 → UTF-8
    int ulen = WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, nullptr, 0, nullptr, nullptr);
    if (ulen <= 0) return "";

    std::string utf8(ulen, '\0');
    WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, &utf8[0], ulen, nullptr, nullptr);

    // 移除多余的终止符（API 自动添加的）
    if (!utf8.empty() && utf8.back() == '\0') {
        utf8.pop_back();
    }
    return utf8;
}

string StringCode::Utf8ToGBK(const std::string &utf8Str)
{
    // 获取转换后所需缓冲区大小
    int wideCharLen = MultiByteToWideChar(CP_UTF8, 0, utf8Str.c_str(), -1, nullptr, 0);
    if (wideCharLen == 0) return "";

    // 转换为宽字符（UTF-16）
    wchar_t *wideCharBuffer = new wchar_t[wideCharLen];
    if (MultiByteToWideChar(CP_UTF8, 0, utf8Str.c_str(), -1, wideCharBuffer, wideCharLen) == 0) {
        delete[] wideCharBuffer;
        return "";
    }

    // 获取目标GBK缓冲区大小
    int gbkLen = WideCharToMultiByte(CP_ACP, 0, wideCharBuffer, -1, nullptr, 0, nullptr, nullptr);
    if (gbkLen == 0) {
        delete[] wideCharBuffer;
        return "";
    }

    // 转换为GBK
    char *gbkBuffer = new char[gbkLen];
    if (WideCharToMultiByte(CP_ACP, 0, wideCharBuffer, -1, gbkBuffer, gbkLen, nullptr, nullptr) == 0) {
        delete[] wideCharBuffer;
        delete[] gbkBuffer;
        return "";
    }

    std::string gbkStr(gbkBuffer);

    // 清理内存
    delete[] wideCharBuffer;
    delete[] gbkBuffer;

    return gbkStr;
}

//wstring StringCode::StrToWStr(const std::string &str)
//{
//    std::wstring wstr(str.size(), 0);
//    std::transform(str.begin(), str.end(), wstr.begin(),
//                   [](char c) { return static_cast<wchar_t>(c); }
//    );
//    return wstr;
//}

wstring StringCode::StrToWStr(const std::string &str)
{
    std::wstring wstr(str.size(), 0);
    std::transform(str.begin(), str.end(), wstr.begin(),
                   [](char c) { return static_cast<wchar_t>(c); }
    );
    return wstr;
}

wstring StringCode::StrToWStr(const std::string& str, bool isUtf8)
{
    if (str.empty())
        return L"";

    // 确定源编码：UTF-8或当前系统ANSI编码（GBK）
    UINT codePage = isUtf8 ? CP_UTF8 : CP_ACP;

    // 计算所需宽字符数
    int wcharCount = MultiByteToWideChar(
            codePage,     // 源编码类型
            0,            // 标志位（无特殊处理）
            str.c_str(),  // 源字符串指针
            -1,           // 自动确定长度（包含终止符）
            nullptr,      // 目标缓冲区（为空时计算长度）
            0
    );
    if (wcharCount == 0)
        return L"";

    // 分配缓冲区并执行转换
    std::wstring wstr;
    wstr.resize(wcharCount);  // 包含终止符空间
    MultiByteToWideChar(
            codePage,
            0,
            str.c_str(),
            -1,
            &wstr[0],
            wcharCount
    );

    wstr.pop_back();  // 移除转换后多余的终止符(L'\0')
    return wstr;
}

string StringCode::WStrToStr(const std::wstring &wstr)
{
    if (wstr.empty()) return "";
    int len = WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, NULL, 0, NULL, NULL);
    std::string str(len, 0);
    WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, &str[0], len, NULL, NULL);
    return str;
}

// 获取某个文件夹的所有文件 //
vector<string> GetListDir(const std::string& directoryPath)
{
    // 存储文件名的容器 //
    std::vector<std::string> listDir;

    // 查找文件 //
    WIN32_FIND_DATAA findFileData;
    HANDLE hFind = INVALID_HANDLE_VALUE;

    // 构造搜索路径（例如："C:\\MyFolder\\*"）
    std::string searchPath = directoryPath + "/*";

    hFind = FindFirstFileA(searchPath.c_str(), &findFileData);

    // 如果没有查找到 //
    if (hFind == INVALID_HANDLE_VALUE)
    {
        std::cerr << "FindFirstFile failed for path: " << directoryPath
                  << " Error: " << GetLastError() << std::endl;
        return {""};
    }

    do {
        // 跳过 "." 和 ".." 目录
        if (strcmp(findFileData.cFileName, ".") != 0 &&
            strcmp(findFileData.cFileName, "..") != 0)
        {

            // 检查是否是目录
            if (findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
            {
                // 暂时不作出处理，向容器添加目录 //
                listDir.push_back(findFileData.cFileName);
            }
            else
            {
                // 是文件，添加到容器中
                listDir.push_back(findFileData.cFileName);
            }
        }
    }
    while (FindNextFileA(hFind, &findFileData) != 0);

    DWORD dwError = GetLastError();
    if (dwError != ERROR_NO_MORE_FILES)
    {
        std::cerr << "FindNextFile error: " << dwError << std::endl;
    }

    FindClose(hFind);
    return listDir;
}


// 删除文件 //
bool FileEvent::RemoveFile(const std::string& fileName)
{
    StringCode scd;
    const wchar_t* filePath = scd.StrToWStr(fileName).c_str();

    // 去掉只读属性（可选）
    DWORD attrs = GetFileAttributesW(filePath);
    if (attrs != INVALID_FILE_ATTRIBUTES && (attrs & FILE_ATTRIBUTE_READONLY))
    {
        SetFileAttributesW(filePath, attrs & ~FILE_ATTRIBUTE_READONLY);
    }

    // 直接删除文件
    if (DeleteFileW(filePath))
    {
        return true;
    }
    else
    {
        std::cerr << scd.Utf8ToGBK("删除失败，错误代码: ") << GetLastError() << std::endl;
        return false;
    }
}


// 创建文件夹 //
bool FileEvent::CreateDir(const std::string &fileName)
{
    // 要创建的文件夹路径（注意双反斜杠转义）
    StringCode scd;
    wstring dirName = scd.StrToWStr(fileName);

    // 要创建的文件夹路径（注意双反斜杠转义）
    LPCWSTR folderPath = dirName.c_str();

    // 调用 Windows API 创建文件夹
    BOOL result = CreateDirectoryW(
            folderPath,        // 文件夹路径
            NULL                // 安全属性（可选参数，设为NULL使用默认）
    );

    // 检查是否创建成功
    if (result)
    {
        return true;
    } else
    {
        // 获取错误代码并提示
        return false;
    }

}


// 删除文件夹 //
bool FileEvent::RemoveDir(const std::string& dirPath)
{
    try
    {
        // 检查路径是否存在且是目录
        if (fs::exists(dirPath) && fs::is_directory(dirPath))
        {
            // 递归删除目录及其内容
            uintmax_t n = fs::remove_all(dirPath);
            return true;
        } else
        {
            std::cerr << "Path does not exist or is not a directory: " << scd_cpp.Utf8ToGBK(dirPath) << "\n";
            return false;
        }
    } catch (const fs::filesystem_error& e)
    {
        std::cerr << "Filesystem error\n";
        std::cerr << "Path: " << e.path1()<< "\n";
        return false;
    } catch (const std::exception& e)
    {
        std::cerr << "General error\n";
        return false;
    }
    return true;
}


// 写入日志 //
bool FileEvent::WriteLog(const std::string &str, const std::string &fileName)
{
    // 1. 使用正确的文件名参数打开文件 //
    FILE *file = fopen(fileName.c_str(), "a");  // 关键修改：fileName而非str

    if (file == nullptr)
    {
        printf("Unable to open the log file!\n");
        return false;
    }

    // 2. 正确写入传入的日志内容（自动追加换行符） //
    fprintf(file, "%s\n", str.c_str());  // 关键修改：使用str内容

    // 3. 必须关闭文件释放资源 //
    fclose(file);  // 关键补充：防止资源泄漏

    return true;
}


bool FileEvent::CopyDir(const fs::path& sourcePath, const fs::path& targetPath)
{
    try
    {
        // 检查源路径
        if (!fs::exists(sourcePath))
        {
            std::cerr<<"Source path does not exist: " + sourcePath.string();
            return false;
        }
        if (!fs::is_directory(sourcePath))
        {
            std::cerr<<"Source path is not a directory: " + sourcePath.string();
            return false;
        }

        // 在目标路径下创建同名文件夹
        auto targetDir = targetPath / sourcePath.filename(); // 关键修改：添加同名子目录
        fs::create_directories(targetDir);

        // 递归复制内容
        for (const auto& entry : fs::directory_iterator(sourcePath))
        {
            const auto& path = entry.path();
            auto target = targetDir / path.filename(); // 目标路径修正

            if (fs::is_directory(path))
            {
                // 递归复制子目录
                CopyDir(path, targetDir);
            } else if (fs::is_regular_file(path))
            {
                fs::copy_file(path, target, fs::copy_options::overwrite_existing);
            }
        }
    } catch (const fs::filesystem_error& e)
    {
        std::cerr << "File system error: " << e.what() << '\n';
        return false;
    } catch (const std::exception& e)
    {
        std::cerr << "Standard exception: " << e.what() << '\n';
        return false;
    }
    return true;
}


/****************** 判断是否为管理员 ******************/
bool wkp::isAdmin()
{
    HANDLE hToken = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken))
        return false;

    TOKEN_ELEVATION elevation;
    DWORD dwSize;
    bool bIsAdmin = false;

    if (GetTokenInformation(hToken, TokenElevation, &elevation, sizeof(elevation), &dwSize))
    {
        bIsAdmin = elevation.TokenIsElevated;
    }

    CloseHandle(hToken);
    return bIsAdmin;
}

bool wkp::openAdmin()
{
    WCHAR szPath[MAX_PATH];
    if (!GetModuleFileNameW(nullptr, szPath, MAX_PATH))
    {
        std::cerr << "GetModuleFileName failed (" << GetLastError() << ")\n";
        return false;
    }

    SHELLEXECUTEINFOW sei = { sizeof(sei) };
    sei.lpVerb = L"runas";
    sei.lpFile = szPath;
    sei.nShow = SW_SHOWNORMAL;
    sei.fMask = SEE_MASK_NOASYNC | SEE_MASK_NOCLOSEPROCESS;

    if (!ShellExecuteExW(&sei))
    {
        DWORD err = GetLastError();
        if (err == ERROR_CANCELLED)
            std::cerr << "User refused UAC prompt.\n";
        else
            std::cerr << "ShellExecuteEx failed (" << err << ")\n";
        return false;
    }
    return true;
}

double wkp::getRunTime()
{
    return std::chrono::duration<double>(
            std::chrono::high_resolution_clock::now().time_since_epoch()
    ).count();
}

void wkp::addTempPath(const std::string &path)
{
    // 转为宽字符串 //
    StringCode scd;
    wstring temp_path = scd.StrToWStr(path, true);

    // 获取当前PATH
    std::vector<wchar_t> buffer(32767);
    DWORD len = GetEnvironmentVariableW(L"PATH", buffer.data(), 32767);
    // 构造新PATH
    std::wstring newEnvPath = temp_path + L";" + std::wstring(buffer.data(), len);
    // 设置新PATH
    SetEnvironmentVariableW(L"PATH", newEnvPath.c_str());
}

void wkp::addTempPath(const std::wstring &newPath)
{
    // 获取当前PATH
    std::vector<wchar_t> buffer(32767);
    DWORD len = GetEnvironmentVariableW(L"PATH", buffer.data(), 32767);

    // 构造新PATH
    std::wstring newEnvPath = newPath + L";" + std::wstring(buffer.data(), len);

    // 设置新PATH
    SetEnvironmentVariableW(L"PATH", newEnvPath.c_str());
}

void wkp::useConsoleUtf8()
{
    // 设置输入输出都为UTF8 //
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
}

void wkp::openDir(const std::string &path)
{
    LPCSTR folderPath = (LPCSTR) path.c_str();

    // 使用ShellExecute打开文件夹
    ShellExecuteA(nullptr, "open", folderPath, nullptr, nullptr, SW_SHOW);
}


/**************** 清理工作 ******************/
void cleanup_check()
{
//    cout<<"开始清理工作\n";
    // 清理未释放的鼠标 //
    MouseEvent mouse;
    // 释放鼠标，如果鼠标按下 //
    if (mouse_flag.mouse_left_down)
    {
        // 释放左键
        mouse.MouseUp("left");
        mouse_flag.mouse_left_down = False;  // 更新标志
//        cout<<"左键已释放\n";
    }
    else if(mouse_flag.mouse_right_down)
    {
        // 释放右键
        mouse.MouseUp("right");
        mouse_flag.mouse_right_down = False;  // 更新标志
//        cout<<"右键已释放\n";
    }

    // 清理未释放的键盘 //
    // 释放 Ctrl、Alt、Shift 和 Win 键
    ////// 释放键盘 //////
    int len = sizeof (free_keys.key_code)/sizeof (free_keys.key_code[0]);
    for (int f=0; f<len; f++)
    {
        if (free_keys.key_code[f] !=0)
        {
            INPUT input = {0};
            input.type = INPUT_KEYBOARD;
            input.ki.wVk = free_keys.key_code[f];  // 键位吗码
            input.ki.dwFlags = KEYEVENTF_KEYUP;
            SendInput(1, &input, sizeof(INPUT));
//            printf("释放忘记释放的按键: %d \n", free_keys.key_code[f]);
        }
    }

    // 检查鼠标事件钩子是否被注销 //
    if (hMouseHook != NULL || hMouseHook!= nullptr)
    {
        // 检查全局变量hMouseHook是否有效
        if (hMouseHook != NULL)
        {
            // 移除鼠标钩子
            UnhookWindowsHookEx(hMouseHook);
            hMouseHook = NULL; // 将全局变量置为空
            // 发送程序结束消息
        }
//    exit(0); // 退出程序
    }

    // 释放 hOneKeyEvent 单按键监听 //
    if (hOneKeyEvent != NULL || hOneKeyEvent!= nullptr)
    {
        // 确保钩子被卸载
        UnhookWindowsHookEx(hOneKeyEvent);       // 卸载钩子
        hOneKeyEvent = nullptr;  // 重置钩子句柄
    }

    // 重新检查键盘快捷键hHook是否被注销 //
    if (hHook != NULL || hHook!= nullptr)
    {
        // 确保钩子被卸载
        UnhookWindowsHookEx(hHook);       // 卸载钩子
        hHook = nullptr;  // 重置钩子句柄
    }

    // 发送程序结束消息
    PostQuitMessage(0);
    exit(0);
}

// 清理函数调用 //
void ExitCheckWork()
{
    atexit(cleanup_check);  // 退出所执行的任务
}

/*******************************/
void mouse0()
{
    MouseEvent m;
    m.ListenMouseEvent();
}

bool sss = true;
void mouse()
{
    MouseEvent m;
    int s = 0;
    while (sss)
    {
        s = m.GetMouseCode();
        switch (s)
        {
            case WM_FORWARDOWN:
                printf("按钮2，前进! 按下\n");
                break;
            case WM_FORWARDUP:
                printf("按钮2，前进! 抬起\n");
                break;
            case WM_BACKSPACEDOWN:
                printf("按钮1后退按下\n");
                break;
            case WM_BACKSPACEUP:
                printf("按钮1后退抬起\n");
                break;
            case WM_LEFTDOWN:
                printf("左键按下\n");
                break;
            case WM_LEFTUP:
                printf("左键抬起\n");
                break;
        }
    }
}


int main()
{
    wkp::openDir("D:\\QtImageTools\\python嵌入式");
//    wkp::useConsoleUtf8();
//    MouseEvent m;
//    std::thread T0(mouse0);
//    std::thread T1(mouse);
//    T0.detach();
//    T1.detach();
//
//    KeyBoardEvent k;
//    k.AddHotKey("esc", [&](){
//        sss = false;
//        KeyBoardEvent::ClearHotKey();
//    });
//    k.WaitHotKey();
    return 0;
}


//int main()
//{
//    FileEvent f;
//    f.WriteLog("测试日志", "error_log.txt");
//    f.WriteLog("测试日志ky", "error_log.txt");
//
//    std::string Path = "D:\\QtImageTools\\python嵌入式";
////    // 添加到PATH
////    wkp::addTempPath(Path);
////
////    system("where python");
//    return 0;
//}