#include <iostream>
#include <winKeyPressH.hpp>
#include <unistd.h>
#include <cstdio>
#include <mutex>
#include <atomic>
#include <windows.h>
#include <vector>
using namespace std;

vector<MousePosition> PositionList;

KeyBoardEvent k;


bool run = true;

void T_Mouse()
{
    MouseEvent mouse;
    mouse.ListenMouseEvent();
}

void T_Key()
{
    ;
}



int main()
{
    MouseEvent m;
    m.MouseClick(500, 300, 1, "left");
    return 0;
}

