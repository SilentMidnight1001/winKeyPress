#ifndef WinKeyPress
#define WinKeyPress

#include <iostream>
#include <ShellScalingApi.h>      // Windows DPI 缩放相关 API
#include <windows.h>
#include <cstdio>
#include <ctime>
#include <csignal> // For signal()
#include <regex>  // 正则表达头文件
#include <vector>  // 自动管理内存
#include <thread>
#include <atomic>
#include <functional>
#include <algorithm>
#include <stdexcept>
#include <fstream>
#include <chrono>
#include <filesystem>
#include <system_error>
#include <filesystem>
#include <wincodec.h>  // WIC 头文件
#include <shellapi.h>
using namespace std;
namespace fs = std::filesystem;


// 在全局变量区新增状态标记 鼠标监听 //
static std::atomic<bool> mouseEventProcessed(true);  // 原子操作保证线程安全

// 在全局变量区新增状态标记 单个按键监听 //
static std::atomic<bool> OneKeyEventProcessed(true);  // 原子操作保证线程安全


// 布尔值 //
enum BOOLS {True=1, False=0};

/************** 侧边按钮按下抬起特殊记忆 ****************/
/*
自定义鼠标侧边按钮，侧边按下为523，抬起524，以这个数字加上按钮编号
按钮1按下为5231，抬起为5241，按钮2按下5232， 抬起5242
*/
// 侧边按下 //
const WPARAM XBUTTON1DOWN = 5231;
const WPARAM XBUTTON2DOWN = 5232;

// 侧边抬起 //
const WPARAM XBUTTON1UP = 5241;
const WPARAM XBUTTON2UP = 5242;

// 鼠标事件枚举，(左键按下:1001,抬起:-1001); (中键按下:1002,抬起:-1002); (右键按下:1003, :-1003) //
enum MOUSECODE {
    /************** 鼠标按下 ****************/
    WM_LEFTDOWN=1001,  WM_ROLLDOWN=1002, WM_RIGHTDOWN=1003, WM_FORWARDOWN=1004,
    WM_BACKSPACEDOWN=1005,

    /************** 鼠标抬起 ****************/
    WM_LEFTUP=-1001, WM_ROLLUP=-1002, WM_RIGHTUP=-1003, WM_FORWARDUP=-1004,
    WM_BACKSPACEUP=-1005,
};


enum KEYCODEENUM {
    /*************** 按下虚键码整数 ****************/
    // 26字母键值码按下 //
    KEY_A_DOWN=65, KEY_B_DOWN=66, KEY_C_DOWN=67, KEY_D_DOWN=68, KEY_E_DOWN=69, KEY_F_DOWN=70,
    KEY_G_DOWN=71, KEY_H_DOWN=72, KEY_I_DOWN=73, KEY_J_DOWN=74, KEY_K_DOWN=75, KEY_L_DOWN=76,
    KEY_M_DOWN=77, KEY_N_DOWN=78, KEY_O_DOWN=79, KEY_P_DOWN=80, KEY_Q_DOWN=81, KEY_R_DOWN=82,
    KEY_S_DOWN=83, KEY_T_DOWN=84, KEY_U_DOWN=85, KEY_V_DOWN=86, KEY_W_DOWN=87, KEY_X_DOWN=88,
    KEY_Y_DOWN=89, KEY_Z_DOWN=90,

    // 0-9数字键值码 //
    KEY_0_DOWN=48, KEY_1_DOWN=49, KEY_2_DOWN=50, KEY_3_DOWN=51, KEY_4_DOWN=52, KEY_5_DOWN=53,
    KEY_6_DOWN=54, KEY_7_DOWN=55, KEY_8_DOWN=56, KEY_9_DOWN=57,

    // 特俗键键值码 //
    KEY_F1_DOWN=112, KEY_F2_DOWN=113, KEY_F3_DOWN=114, KEY_F4_DOWN=115, KEY_F5_DOWN=116, KEY_F6_DOWN=117,
    KEY_F7_DOWN=118, KEY_F8_DOWN=119, KEY_F9_DOWN=120, KEY_F10_DOWN=121, KEY_F11_DOWN=122, KEY_F12_DOWN=123,
    KEY_ESC_DOWN=27, KEY_TAB_DOWN=9, KEY_ENTER_DOWN=13, KEY_BACKSPACE_DOWN=8, KEY_SPACE_DOWN=32, KEY_DELETE_DOWN=127,
    KEY_UP_DOWN=38, KEY_DOWN_DOWN=40, KEY_LEFT_DOWN=37, KEY_RIGHT_DOWN=39, KEY_CTRL_DOWN=162, KEY_ALT_DOWN=164,
    KEY_SHIFT_DOWN=160, KEY_CAPSLOCK_DOWN=20, KEY_CTRL_LEFT_DOWN=163, KEY_SHIFT_RIGHT_DOWN=161, KEY_ALT_RIGHT_DOWN=165,

    /*************** 抬起,虚键码负数 ****************/
    KEY_A_UP =-65, KEY_B_UP=-66, KEY_C_UP=-67, KEY_D_UP=-68, KEY_E_UP=-69, KEY_F_UP=-70,
    KEY_G_UP=-71, KEY_H_UP=-72, KEY_I_UP=-73, KEY_J_UP=-74, KEY_K_UP=-75, KEY_L_UP=-76,
    KEY_M_UP=-77, KEY_N_UP=-78, KEY_O_UP=-79, KEY_P_UP=-80, KEY_Q_UP=-81, KEY_R_UP=-82,
    KEY_S_UP=-83, KEY_T_UP=-84, KEY_U_UP=-85, KEY_V_UP=-86, KEY_W_UP=-87, KEY_X_UP=-88,
    KEY_Y_UP=-89, KEY_Z_UP=-90,  // 26字母键值码

    KEY_0_UP=-48, KEY_1_UP=-49, KEY_2_UP=-50, KEY_3_UP=-51, KEY_4_UP=-52, KEY_5_UP=-53,
    KEY_6_UP=-54, KEY_7_UP=-55, KEY_8_UP=-56, KEY_9_UP=-57,  // 0-9数字键值码

    KEY_F1_UP=-112, KEY_F2_UP=-113, KEY_F3_UP=-114, KEY_F4_UP=-115, KEY_F5_UP=-116, KEY_F6_UP=-117,
    KEY_F7_UP=-118, KEY_F8_UP=-119, KEY_F9_UP=-120, KEY_F10_UP=-121, KEY_F11_UP=-122, KEY_F12_UP=-123,
    KEY_ESC_UP=-27, KEY_TAB_UP=-9, KEY_ENTER_UP=-13, KEY_BACKSPACE_UP=-8, KEY_SPACE_UP=-32, KEY_DELETE_UP=-127,
    KEY_UP_UP=-38, KEY_DOWN_UP=-40, KEY_LEFT_UP=-37, KEY_RIGHT_UP=-39, KEY_CTRL_UP=-162, KEY_ALT_UP=-164,
    KEY_SHIFT_UP=-160, KEY_CAPSLOCK_UP=-20, KEY_CTRL_RIGHT_UP=-163, KEY_SHIFT_RIGHT_UP=-161, KEY_ALT_RIGHT_UP=-165,
};

// 监听鼠标按下的虚键码 //
static WPARAM MOUSE_CODE = 0;


typedef struct
{
    long ONE_KEY_CODE;
    bool real_time;
}ONE_KEY_CODE_STRUCT;

static ONE_KEY_CODE_STRUCT  ONE_KEY_CODES;
// 定义一个检查是否注册末尾清理的变量 //
static bool autoClear = False;

// 定义一个程序结束清理的函数 //
void cleanup_check();

/************* 屏幕事件 ****************/
typedef struct  // 声明结构体获取屏幕大小
{
    int x;
    int y;
} ScreenSize;  // 定义标签

typedef struct MousePosition  // 获取光标所在当前位置
{
    LONG x;
    LONG y;
}MousePosition;

ScreenSize GetScreenSize(bool out_put);  // 获取分辨率函数，布偶值选择是否输出坐标

MousePosition GetMousePosition(bool out_put);  // 获取光标目前所在的坐标，鼠标坐标，布偶值选择是否输出坐标


/************* press up flag **************/

typedef struct MouseFlag  // 键盘按下的标志，后期程序结束如果程序员忘记是覅则自动释放按键
{
    bool mouse_left_down;  // 左键标志
    bool mouse_right_down;  // 右键标准
}MouseFlag;

static MouseFlag mouse_flag;  // 实例化结构体

/************** 获取图像坐标 **************/

// 存放坐标的结构体 //
typedef struct
{
    int x;
    int y;
    bool result;
}ImagePosition;


/***************** 图像处理类 ******************/
class ImageEvent
{
private:
    bool SaveBitmapToFile(HBITMAP hBitmap, const wchar_t* filename);
    bool isCaptureScreen = false;

    string getImageNameFunc(const string &imgPath);
    string getImageNameFunc(const string &imgPath, const string &name);
public:
    // 获取坐标函数 //
    ImagePosition GetImagePosition(const string& filePath, double threshold);

    bool SetImageFormat(const string &imgPath, const string &targetImageFormat);

    bool CaptureScreen(const string &imageName);  // const string & imageName  wchar_t* filename
    bool CaptureScreen(const string &imageName, const string &targetImageSavePath);  // const string & imageName  wchar_t* filename

    bool SetImageSize(const string &imgPath, int width, int height);  // 对原图片修改
    bool SetImageSize(const string &imgPath, int width, int height, const string &outPutName);  // 输出图片
    bool SetImageSize(const string &imgPath, int width, int height, const string &targetImageSavePath, const string &outPutName);  // 输出图片到指定目录
    ~ImageEvent();
};



// 获取指定文件夹的所有文件 //
vector<string> GetListDir(const std::string& directoryPath);


/********************** 鼠标事件 **********************/
class MouseEvent
{
public:
    MouseEvent()
    {
        // 检查是否注册末尾清理函数，False为没有注册 //
        if (!autoClear)
        {
            std::atexit(cleanup_check);
            autoClear = True;  // 标志设置为True表示注册
        }

        UINT systemCode = GetACP();
        if (systemCode == 65001)
        {
            // 当系统编码为65001时，将其改为GBK，以GBK模式输出 //
            SetConsoleOutputCP(936);  // 设置编码65001控制台输出为UTF-8
            SetConsoleCP(65001);  // 设置控制台输入为UTF-8
        }
    }

    void MouseMoveTo(int x, int y);  // x,y坐标;
    void MouseMoveTo(int targetX, int targetY, float delay);

    void MouseDown(const string& button="left");  // 鼠标按下键位

    void MouseUp(const string& button);  // 鼠标释放

    void MouseClick(int x, int y, int clicks=1, const string& button="left", float delay=0);  // 鼠标点击函数,默认左键
    void MouseClick(MousePosition &positions, int clicks=1, const string& button="left", float delay=0);  // 直接传入结构体变量
    void MouseClick(int x, int y, int clicks=1, float delay=0);

    void MouseRoll(int move);  // 鼠标滚轮,正数向上负数向下

    void ListenMouseEvent();  // 监听鼠标事件 //

    int GetMouseCode();  // 获取鼠标虚键码 //

    static void ExitMouseEvent();  // 退出鼠标监听事件 //

    static void UninstallMouseEvent();  // 注销所有鼠标事件，但是不退出程序 //
};


/************************** 键盘事件 *****************************/
// 字符串复制到剪切板 //
typedef struct copy_str_structs  // 字符窜剪切的结构体(防止后续重复利用相同字符窜)
{
    const char* textToCopy;  // 一个常量指针字符窜
    void (*copy_str_in)(struct copy_str_structs);  // 复制到剪切板的函数，后续包裹到CopyStr中
}copy_str_structs;

// 检查键盘是否松开结构体 //
typedef struct PressHotKeyNameUp
{
    int key_num;  // 按下的数量
    int key_code[300];
}PressHotKeyNameUp;  // 释放按下的按键
static PressHotKeyNameUp free_keys = {0, 0}; // 释放按键


// 功能实现类 //
// 存放快捷键虚键码的结构体与容器 //
typedef struct
{
    int key1;
    int key2;
    int key3;
    int key4;
    int FuncIndex;
    int FuncID;  // 函数的索引顺序，ID号
}KeyCode;

// 存放快捷键虚键码的容器 //
static vector<KeyCode>key_code;


// 快捷键的虚键码 //
static vector<int>fourKeyCode;  // 四个键位的键值
static vector<int> threeKeyCode;  // 三个键位的键值
static vector<int> twoKeyCode;  // 两个键位的键值
static vector<int> oneKeyCode;  // 一个键位的键值

// 存放快捷键函数的容器 //
//vector<void (*)()>fourKeyFunc;
//vector<void (*)()>threeKeyFunc;
//vector<void (*)()>twoKeyFunc;
//vector<void (*)()>oneKeyFunc;

// 存放快捷键函数的容器，可以存放对象函数 //
static vector<std::function<void()>>fourKeyFunc;
static vector<std::function<void()>>threeKeyFunc;
static vector<std::function<void()>>twoKeyFunc;
static vector<std::function<void()>>oneKeyFunc;

// 快捷键计数器 //
static int fourKeyIndex = 0;  // 四个键位的索引
static int threeKeyIndex = 0;  // 三个键位的索引
static int twoKeyIndex = 0;  // 两个键位的索引
static int oneKeyIndex = 0;  // 一个键位的索引

class KeyBoardEvent
{
public:
    KeyBoardEvent()
    {
        // 检查是否注册末尾清理函数，False为没有注册 //
        if (!autoClear)
        {
            // 注册清理函数 //
            std::atexit(cleanup_check);
            autoClear = True;  // 标志设置为True表示注册
        }
        UINT systemCode = GetACP();
        if (systemCode == 65001)
        {
            // 当系统编码为65001时，将其改为GBK，以GBK模式输出 //
            SetConsoleOutputCP(936);  // 设置编码65001控制台输出为UTF-8
            SetConsoleCP(65001);  // 设置控制台输入为UTF-8
        }
    }
    // 功能部分
    void KeyDown(const string& key);  // 键盘按下

    void KeyUp(const string& key);  // 键盘释放

    void PressKey(const string& key); // 按键

    template<typename... Args>
    void PressHotKey(const std::string& first, Args... rest)
    {
        KeyDown(first);       // 按下当前键
        PressHotKey(rest...); // 递归处理剩余键
        KeyUp(first);         // 递归返回后释放当前键（逆序释放）
    }
    // 递归终止条件
    void PressHotKey() {}

    void WriteStr(string output); // 输入字符窜函数但仅可用英文

    void CopyStr(const char *str);  // 复制字符串函数

//    string PasteStr();  // 返回字符串的一个函数

//    ~KeyBoardEvent()

    // 注册快捷键,普通函数与类函数 //
    void AddHotKey(const string &key, std::function<void()> targetVoidFunc);

    void WaitHotKey();  // 监听快捷键函数

    // 单个按键监听 //
    void ListenOneKeyEvent(bool real_time);
    void ListenOneKeyEvent();

    // 获取键盘状态码 //
    long GetOneKeyCode();


    // 清理快捷键 //
    static void ClearHotKey();  // 清除快捷键,设置static静态函数可以被成员函数实力化后回调 //

    static void UninstallHotKeyEvent();  // 注销所有快捷键，但是不退出程序 //


    // 清理单个按键监听 //
    static void ExitOneKeyEvent();
    static void UninstallOneKeyEvent();  // 注销单个按键监听，但是不退出程序 //
};


/*********************** 更改字符串编码 **************************/
class StringCode
{
public:
    std::string GBKToUTF8(const std::string& gbkStr);
    std::string Utf8ToGBK(const std::string& utf8Str);
    std::wstring StrToWStr(const std::string& str);
    std::wstring StrToWStr(const std::string& str, bool isUtf8);
    std::string WStrToStr(const std::wstring& wstr);
};


/******************** 文件操作 ***************************/
class FileEvent
{
public:
    // 删除文件函数 //
    bool RemoveFile(const std::string& fileName);
    // 创建文件函数 //
    bool CreateDir(const std::string& fileName);
    bool RemoveDir(const std::string& dirPath);
    // 写日志函数 //
    bool WriteLog(const std::string &str, const std::string &fileName);
    bool CopyDir(const fs::path& sourcePath, const fs::path& targetPath);
};


// 异常类 //
class ImageNotFoundException : public std::exception
{
private:
    std::string message;

public:
    explicit ImageNotFoundException(const std::string& msg) : message(msg) {}
    const char* what() const noexcept override
    {
        return message.c_str();
    }
};

namespace wkp
{
    // 检查已经使用管理员权限重新打开脚本 //
    bool isAdmin();
    bool openAdmin();
    // 运行时间 //
    double getRunTime();
    // 添加临时环境变量 //
    void addTempPath(const std::string& path);
    void addTempPath(const std::wstring& newPath);
    // 使用控制台编码 //
    void useConsoleUtf8();

    // 后台打开文件夹 //
    void openDir(const std::string& path);

    // 冒泡排序法 //
    vector<int>sort(const int *numList, int numListSize, const string &mode);

    // 获取当前时间 //
    string getNowTime();

    std::string getExePath();

    class Open
    {
    private:
        // 读写文件 //
        FILE *ipt = nullptr;
        FILE *opt = nullptr;

        // 文件模式 //
        fs::path filePath;
        fs::path mode;

        // 二进制读取文件大小 //
        long file_size;

        bool ipt_isOpen = false;
        bool opt_isOpen = false;

    public:
        // 默认构造函数 //
        Open() = default;
        Open(const string &file_path, const string &file_mode);
        // 打开文件 //
        void open(const string &file_path, const string &file_mode);
        // 检查是否成功打开 //
        bool isOpen();
        // 读取文件 //
        string read();
        vector<string> readLine();

        // 二进制读取文件 //
        std::vector<unsigned char> readBinary();

        // 写入文件 //
        void write(const string &str);

        // 写入二进制文件 //
        void writeBinary(const std::vector<unsigned char> &data);

        template<typename T>
        void writeBinary(const T &data);

        // 关闭文件 //
        void close();

        ~Open();
    };

    string getConsoleEncoding();
}

// 回调清理函数 //
void ExitCheckWork();


#endif