#pragma once
#include <iostream>
#include <ShellScalingApi.h>      // Windows DPI 缩放相关 API
#include <windows.h>
#include <cstdio>
#include <ctime>
#include <csignal> // For signal()
#include <regex>  // 正则表达头文件
#include <vector>  // 自动管理内存
#include <thread>
#include <atomic>
#include <functional>
#include <algorithm>
#include <stdexcept>
#include <fstream>
#include <chrono>
#include <list>
#include <filesystem>
#include <map>
#include <system_error>
#include <tlhelp32.h>
#include <random>
#include <typeinfo>
#include <sstream>
#include <wincodec.h>  // WIC 头文件
#include <shellapi.h>

namespace fs = std::filesystem;
using std::string;
using std::vector;
using std::wstring;
using std::ofstream;
using std::ifstream;
using std::cout;
using std::endl;

/****************** 调试器符号 ******************/
#ifndef WkpDebug
#define WkpDebug
#endif

/****************** mingw专用 ******************/
#ifndef WkpMinGW
#define WkpMinGW
#endif

/****************** Vs编译器专用 ******************/
//#ifndef WkpVs
//#define WkpVs
//#endif

// 改为正确的导出/导入模式：
#ifdef WkpDebug
#define WKP __declspec(dllexport)
#else
#define WKP __declspec(dllimport)
#endif

// 在全局变量区新增状态标记 鼠标监听 //
static std::atomic<bool> mouseEventProcessed(true);  // 原子操作保证线程安全

// 在全局变量区新增状态标记 单个按键监听 //
static std::atomic<bool> OneKeyEventProcessed(true);  // 原子操作保证线程安全

// 在全局变量区新增状态标记 单个按键监听 //
static std::atomic<bool> listenHotKey(true);  // 原子操作保证线程安全


/************** 侧边按钮按下抬起特殊记忆 ****************/
/*
自定义鼠标侧边按钮，侧边按下为523，抬起524，以这个数字加上按钮编号
按钮1按下为5231，抬起为5241，按钮2按下5232， 抬起5242
*/
// 侧边按下 //
const WPARAM XBUTTON1DOWN = 5231;
const WPARAM XBUTTON2DOWN = 5232;

// 侧边抬起 //
const WPARAM XBUTTON1UP = 5241;
const WPARAM XBUTTON2UP = 5242;

// 鼠标事件枚举，(左键按下:1001,抬起:-1001); (中键按下:1002,抬起:-1002); (右键按下:1003, :-1003) //
enum MOUSECODE {
    /************** 鼠标按下 ****************/
    WM_LEFTDOWN=1001,  WM_ROLLDOWN=1002, WM_RIGHTDOWN=1003, WM_FORWARDOWN=1004,
    WM_BACKSPACEDOWN=1005,

    /************** 鼠标抬起 ****************/
    WM_LEFTUP=-1001, WM_ROLLUP=-1002, WM_RIGHTUP=-1003, WM_FORWARDUP=-1004,
    WM_BACKSPACEUP=-1005,
};


enum KEYCODEENUM {
    /*************** 按下虚键码整数 ****************/
    // 26字母键值码按下 //
    KEY_A_DOWN=65, KEY_B_DOWN=66, KEY_C_DOWN=67, KEY_D_DOWN=68, KEY_E_DOWN=69, KEY_F_DOWN=70,
    KEY_G_DOWN=71, KEY_H_DOWN=72, KEY_I_DOWN=73, KEY_J_DOWN=74, KEY_K_DOWN=75, KEY_L_DOWN=76,
    KEY_M_DOWN=77, KEY_N_DOWN=78, KEY_O_DOWN=79, KEY_P_DOWN=80, KEY_Q_DOWN=81, KEY_R_DOWN=82,
    KEY_S_DOWN=83, KEY_T_DOWN=84, KEY_U_DOWN=85, KEY_V_DOWN=86, KEY_W_DOWN=87, KEY_X_DOWN=88,
    KEY_Y_DOWN=89, KEY_Z_DOWN=90,

    // 0-9数字键值码 //
    KEY_0_DOWN=48, KEY_1_DOWN=49, KEY_2_DOWN=50, KEY_3_DOWN=51, KEY_4_DOWN=52, KEY_5_DOWN=53,
    KEY_6_DOWN=54, KEY_7_DOWN=55, KEY_8_DOWN=56, KEY_9_DOWN=57,

    // 特俗键键值码 //
    KEY_F1_DOWN=112, KEY_F2_DOWN=113, KEY_F3_DOWN=114, KEY_F4_DOWN=115, KEY_F5_DOWN=116, KEY_F6_DOWN=117,
    KEY_F7_DOWN=118, KEY_F8_DOWN=119, KEY_F9_DOWN=120, KEY_F10_DOWN=121, KEY_F11_DOWN=122, KEY_F12_DOWN=123,
    KEY_ESC_DOWN=27, KEY_TAB_DOWN=9, KEY_ENTER_DOWN=13, KEY_BACKSPACE_DOWN=8, KEY_SPACE_DOWN=32, KEY_DELETE_DOWN=127,
    KEY_UP_DOWN=38, KEY_DOWN_DOWN=40, KEY_LEFT_DOWN=37, KEY_RIGHT_DOWN=39, KEY_CTRL_DOWN=162, KEY_ALT_DOWN=164,
    KEY_SHIFT_DOWN=160, KEY_CAPSLOCK_DOWN=20, KEY_CTRL_LEFT_DOWN=163, KEY_SHIFT_RIGHT_DOWN=161, KEY_ALT_RIGHT_DOWN=165,

    /*************** 抬起,虚键码负数 ****************/
    KEY_A_UP =-65, KEY_B_UP=-66, KEY_C_UP=-67, KEY_D_UP=-68, KEY_E_UP=-69, KEY_F_UP=-70,
    KEY_G_UP=-71, KEY_H_UP=-72, KEY_I_UP=-73, KEY_J_UP=-74, KEY_K_UP=-75, KEY_L_UP=-76,
    KEY_M_UP=-77, KEY_N_UP=-78, KEY_O_UP=-79, KEY_P_UP=-80, KEY_Q_UP=-81, KEY_R_UP=-82,
    KEY_S_UP=-83, KEY_T_UP=-84, KEY_U_UP=-85, KEY_V_UP=-86, KEY_W_UP=-87, KEY_X_UP=-88,
    KEY_Y_UP=-89, KEY_Z_UP=-90,  // 26字母键值码

    KEY_0_UP=-48, KEY_1_UP=-49, KEY_2_UP=-50, KEY_3_UP=-51, KEY_4_UP=-52, KEY_5_UP=-53,
    KEY_6_UP=-54, KEY_7_UP=-55, KEY_8_UP=-56, KEY_9_UP=-57,  // 0-9数字键值码

    KEY_F1_UP=-112, KEY_F2_UP=-113, KEY_F3_UP=-114, KEY_F4_UP=-115, KEY_F5_UP=-116, KEY_F6_UP=-117,
    KEY_F7_UP=-118, KEY_F8_UP=-119, KEY_F9_UP=-120, KEY_F10_UP=-121, KEY_F11_UP=-122, KEY_F12_UP=-123,
    KEY_ESC_UP=-27, KEY_TAB_UP=-9, KEY_ENTER_UP=-13, KEY_BACKSPACE_UP=-8, KEY_SPACE_UP=-32, KEY_DELETE_UP=-127,
    KEY_UP_UP=-38, KEY_DOWN_UP=-40, KEY_LEFT_UP=-37, KEY_RIGHT_UP=-39, KEY_CTRL_UP=-162, KEY_ALT_UP=-164,
    KEY_SHIFT_UP=-160, KEY_CAPSLOCK_UP=-20, KEY_CTRL_RIGHT_UP=-163, KEY_SHIFT_RIGHT_UP=-161, KEY_ALT_RIGHT_UP=-165,
};


/*********** 虚键码对照表 Virtual key code mapping table **************/
static string alphabet_list[] = {"a", "b", "c", "d", "e", "f", "g",
                                 "h", "i", "j", "k", "l", "m",
                                 "n", "o", "p", "q", "r", "s",
                                 "t", "u", "v", "w", "x", "y", "z"  // 26字母
        ,"0", "1", "2", "3", "4", "5", "6"
        , "7", "8", "9"};  // 按键列  // 字母列表


static string function_keys_list [] = {"ctrl", "alt", "shift", "f1", "f2", "f3", "f4", "f5",
                                       "f6", "f7", "f8", "f9", "f10", "f11", "f12", "esc",
                                       "space", "delete", "tab", "enter", "caps", "clear",
                                       "backspace", "win", "pause", "page_up", "page_down", "left_arrow",
                                       "right_arrow", "down_arrow", "up_arrow", "insert", "`", "[", "]",
                                       "\\", ";", "''", ",", ".", "/","-", "=", "，",
                                       "。", "’", "‘"

};

/****************************虚键码列表********************************/
static int alphabet_code[] = {65, 66, 67, 68, 69, 70,
                              71, 72, 73, 74, 75, 76,
                              77, 78, 79, 80, 81, 82,
                              83, 84, 85, 86, 87, 88,
                              89, 90, 48, 49, 50, 51,  // 48 以后是数组
                              52, 53, 54, 55, 56, 57};  // 虚拟键码

static int function_code[] = {VK_CONTROL, VK_MENU, VK_SHIFT, VK_F1, VK_F2, VK_F3,
                              VK_F4, VK_F5, VK_F6, VK_F7, VK_F8, VK_F9, VK_F10,
                              VK_F11, VK_F12, VK_ESCAPE, VK_SPACE, VK_DELETE, VK_TAB,
                              VK_RETURN, VK_CAPITAL, VK_CLEAR, VK_BACK, VK_LWIN, VK_PAUSE,
                              VK_PRIOR, VK_NEXT, VK_LEFT, VK_RIGHT, VK_DOWN, VK_UP, VK_INSERT,
                              VK_OEM_3, VK_OEM_4, VK_OEM_6, VK_OEM_5, VK_OEM_1, VK_OEM_7, 188,
                              190, VK_OEM_2, VK_OEM_MINUS, VK_OEM_PLUS, 188, 190, VK_OEM_7,
                              VK_OEM_7
};


/**************************** 符合虚键码列表 ********************************/
static string symbol_list_not_shift_press[] = {"`", "[", "]", "\\", ";", "''", ",", ".", "/",
                                               "-", "=", "，", "。", "’", "‘"};

static string symbol_list_need_shift_press[] = {"~", "{", "}", "|", ":", "\"\"", "<", ">", "?",
                                                "_", "+","!", "@", "#", "$", "%", "^",
                                                "&", "*", "(",")"};

static string chinese_symbol_shift_press[] = {"：", "“”", "《", "》", "？",
                                              "——", "！" , "￥", "……","（","）"};

//虚键码列表//
static int symbol_not_shift_code[] = {VK_OEM_3, VK_OEM_4, VK_OEM_6, VK_OEM_5, VK_OEM_1, VK_OEM_7, 188,
                                      190, VK_OEM_2, VK_OEM_MINUS, VK_OEM_PLUS, 188, 190, VK_OEM_7,
                                      VK_OEM_7};

static int symbol_need_shift_code[] = {VK_OEM_3, VK_OEM_4, VK_OEM_6, VK_OEM_5, VK_OEM_1, VK_OEM_7, 188,
                                       190, VK_OEM_2, VK_OEM_MINUS, VK_OEM_PLUS, 49,
                                       50, 51,52, 53, 54, 55, 56, 57, 48 };

static int chinese_symbol_shift_code[] = {VK_OEM_1, VK_OEM_7, 188,190, VK_OEM_2,
                                          VK_OEM_MINUS,  49,52, 53, 57, 48 };


// 监听鼠标按下的虚键码 //
static WPARAM MOUSE_CODE = 0;


typedef struct
{
    long ONE_KEY_CODE;
    bool real_time;
}ONE_KEY_CODE_STRUCT;

static ONE_KEY_CODE_STRUCT  ONE_KEY_CODES;
// 定义一个检查是否注册末尾清理的变量 //
static bool autoClear = false;

// 定义一个程序结束清理的函数 //
void cleanup_check();

#ifdef WkpMinGW
    /************* 屏幕事件 ****************/
    typedef struct  // 声明结构体获取屏幕大小
    {
        int x;
        int y;
    } ScreenSize;  // 定义标签

    typedef struct MousePosition  // 获取光标所在当前位置
    {
        LONG x;
        LONG y;
    }MousePosition;

ScreenSize GetScreenSize(bool out_put=true);  // 获取分辨率函数，布偶值选择是否输出坐标

MousePosition GetMousePosition(bool out_put=true);  // 获取光标目前所在的坐标，鼠标坐标，布偶值选择是否输出坐标

/************* press up flag **************/

typedef struct MouseFlag  // 键盘按下的标志，后期程序结束如果程序员忘记是覅则自动释放按键
{
    bool mouse_left_down;  // 左键标志
    bool mouse_right_down;  // 右键标准
}MouseFlag;

static MouseFlag mouse_flag;  // 实例化结构体


#elif defined(WkpVs)
/************* 屏幕事件 ****************/
struct ScreenSize{
        int x;
        int y;
    } ;  // 定义标签

// 获取光标所在当前位置
struct MousePosition
    {
        LONG x;
        LONG y;
    };
ScreenSize GetScreenSize(bool out_put=true);  // 获取分辨率函数，布偶值选择是否输出坐标

MousePosition GetMousePosition(bool out_put=true);  // 获取光标目前所在的坐标，鼠标坐标，布偶值选择是否输出坐标

/************* press up flag **************/

struct MouseFlag  // 键盘按下的标志，后期程序结束如果程序员忘记是覅则自动释放按键
{
    bool mouse_left_down;  // 左键标志
    bool mouse_right_down;  // 右键标准
};

static MouseFlag mouse_flag;  // 实例化结构体

#endif

/********************** 鼠标事件 **********************/
class MouseEvent
{
public:
    MouseEvent()
    {
        // 设置进程 DPI 感知级别，确保在高 DPI 屏幕上正确获取坐标 //
        SetProcessDPIAware();

        // 检查是否注册末尾清理函数，False为没有注册 //
        if (!autoClear)
        {
            std::atexit(cleanup_check);
            autoClear = true;  // 标志设置为True表示注册
        }
    }

    void MouseMoveTo(int x, int y);  // x,y坐标;
    void MouseMoveTo(int targetX, int targetY, float delay);

    void MouseDown(const string& button="left");  // 鼠标按下键位

    void MouseUp(const string& button);  // 鼠标释放

    void MouseClick(int x, int y, int clicks=1, const string& button="left", float delay=0);  // 鼠标点击函数,默认左键
    void MouseClick(MousePosition &positions, int clicks=1, const string& button="left", float delay=0);  // 直接传入结构体变量
    void MouseClick(int x, int y, int clicks=1, float delay=0);

    void MouseRoll(int move);  // 鼠标滚轮,正数向上负数向下

    void ListenMouseEvent();  // 监听鼠标事件 //

    int GetMouseCode();  // 获取鼠标虚键码 //

    static void ExitMouseEvent();  // 退出鼠标监听事件 //

    static void UninstallMouseEvent();  // 注销所有鼠标事件，但是不退出程序 //
};


/***************** 图像处理类 ******************/

// 存放坐标的结构体 //
typedef struct
{
    int x;
    int y;
    bool result;
}ImagePosition;

class ImageEvent
{
private:
    bool SaveBitmapToFile(HBITMAP hBitmap, const wchar_t* filename);
    bool isCaptureScreen = false;

    string getImageNameFunc(const string &imgPath);
    string getImageNameFunc(const string &imgPath, const string &name);

    // 区域截图部分 //
    int getEncoderClsid(const WCHAR* format, CLSID* pClsid);
public:
    // 获取坐标函数 //
    ImagePosition GetImagePosition(const string& filePath, double threshold=1, bool notException=false);

    // 新增：在指定区域内获取图像坐标 //
    ImagePosition GetSpecifiedAreaImagePosition(int x1, int y1, int x2, int y2,
                                                const string& filePath, double threshold=1,
                                                bool notException=false);


    bool SetImageFormat(const string &imgPath, const string &targetImageFormat);

    bool CaptureScreen(const string &imageName);  // const string & imageName  wchar_t* filename
    bool CaptureScreen(const string &imageName, const string &targetImageSavePath);  // const string & imageName  wchar_t* filename

    bool SetImageSize(const string &imgPath, int width, int height);  // 对原图片修改
    bool SetImageSize(const string &imgPath, int width, int height, const string &outPutName);  // 输出图片
    bool SetImageSize(const string &imgPath, int width, int height, const string &targetImageSavePath, const string &outPutName);  // 输出图片到指定目录

    void CaptureAreaScreen(const string &saveName, int x1, int y1, int x2, int y2);
    ~ImageEvent();
};


/************************** 键盘事件 *****************************/
#ifdef WkpMinGW
    // 字符串复制到剪切板 //
    typedef struct copy_str_structs  // 字符窜剪切的结构体(防止后续重复利用相同字符窜)
    {
        const char* textToCopy;  // 一个常量指针字符窜
        void (*copy_str_in)(struct copy_str_structs);  // 复制到剪切板的函数，后续包裹到CopyStr中
    }copy_str_structs;

    // 检查键盘是否松开结构体 //
    typedef struct PressHotKeyNameUp
    {
        int key_num;  // 按下的数量
        int key_code[300];
    }PressHotKeyNameUp;  // 释放按下的按键
    static PressHotKeyNameUp free_keys = {0, 0}; // 释放按键


    // 功能实现类 //
    // 存放快捷键虚键码的结构体与容器 //
    typedef struct
    {
        int key1;
        int key2;
        int key3;
        int key4;
        int FuncIndex;
        int FuncID;  // 函数的索引顺序，ID号
    }KeyCode;

    // 存放快捷键虚键码的容器 //
    static vector<KeyCode>key_code;

#elif defined(WkpVs)
// 字符串复制到剪切板 //
// 字符窜剪切的结构体(防止后续重复利用相同字符窜)
struct copy_str_structs{
        const char* textToCopy;  // 一个常量指针字符窜
        void (*copy_str_in)(struct copy_str_structs);  // 复制到剪切板的函数，后续包裹到CopyStr中
    };

    // 检查键盘是否松开结构体 //
struct PressHotKeyNameUp{
        int key_num;  // 按下的数量
        int key_code[300];
    };  // 释放按下的按键
    static PressHotKeyNameUp free_keys = {0, {0}}; // 释放按键


    // 功能实现类 //
    // 存放快捷键虚键码的结构体与容器 //
    typedef struct
    {
        int key1;
        int key2;
        int key3;
        int key4;
        int FuncIndex;
        int FuncID;  // 函数的索引顺序，ID号
    }KeyCode;

    // 存放快捷键虚键码的容器 //
    static vector<KeyCode>key_code;
#endif

// 快捷键的虚键码 //
static vector<int>fourKeyCode;  // 四个键位的键值
static vector<int> threeKeyCode;  // 三个键位的键值
static vector<int> twoKeyCode;  // 两个键位的键值
static vector<int> oneKeyCode;  // 一个键位的键值

// 存放快捷键函数的容器 //
//vector<void (*)()>fourKeyFunc;
//vector<void (*)()>threeKeyFunc;
//vector<void (*)()>twoKeyFunc;
//vector<void (*)()>oneKeyFunc;

// 存放快捷键函数的容器，可以存放对象函数 //
static vector<std::function<void()>>fourKeyFunc;
static vector<std::function<void()>>threeKeyFunc;
static vector<std::function<void()>>twoKeyFunc;
static vector<std::function<void()>>oneKeyFunc;

// 快捷键计数器 //
static int fourKeyIndex = 0;  // 四个键位的索引
static int threeKeyIndex = 0;  // 三个键位的索引
static int twoKeyIndex = 0;  // 两个键位的索引
static int oneKeyIndex = 0;  // 一个键位的索引

class KeyBoardEvent
{
private:
    int getOneKeyCode(string key_name);

public:
    KeyBoardEvent()
    {
        // 检查是否注册末尾清理函数，False为没有注册 //
        if (!autoClear)
        {
            // 注册清理函数 //
            std::atexit(cleanup_check);
            autoClear = true;  // 标志设置为True表示注册
        }
    }
    // 功能部分
    void KeyDown(const string& key);  // 键盘按下

    void KeyUp(const string& key);  // 键盘释放

    void PressKey(const string& key); // 按键

    template<typename... Args>
    void PressHotKey(const std::string& first, Args... rest);
    // 递归终止条件
    void PressHotKey() {}

    void WriteStr(string output); // 输入字符窜函数但仅可用英文

    void CopyStr(const char *str);  // 复制字符串函数

//    string PasteStr();  // 返回字符串的一个函数

//    ~KeyBoardEvent()

    // 注册快捷键,普通函数与类函数 //
    void AddHotKey(const string &key, std::function<void()> targetVoidFunc);

    void WaitHotKey();  // 监听快捷键函数

    // 单个按键监听 //
    void ListenOneKeyEvent(bool real_time);
    void ListenOneKeyEvent();

    // 获取键盘状态码 //
    long GetOneKeyCode();


    // 清理快捷键 //
    static void ClearHotKey();  // 清除快捷键,设置static静态函数可以被成员函数实力化后回调 //

    static void UninstallHotKeyEvent();  // 注销所有快捷键，但是不退出程序 //


    // 清理单个按键监听 //
    static void ExitOneKeyEvent();
    static void UninstallOneKeyEvent();  // 注销单个按键监听，但是不退出程序 //
};

/*********************** 更改字符串编码 **************************/
class StringCode
{
public:
    std::string GBKToUTF8(const std::string& gbkStr);
    std::string Utf8ToGBK(const std::string& utf8Str);
    std::wstring StrToWStr(const std::string& str);
    std::wstring StrToWStr(const std::string& str, bool isUtf8);
    std::string WStrToStr(const std::wstring& wstr);
};

/******************** 文件操作 ***************************/
class FileEvent
{
public:
    // 删除文件函数 //
    bool RemoveFile(const std::string& fileName);
    // 创建文件函数 //
    bool CreateDir(const std::string& fileName);
    bool RemoveDir(const std::string& dirPath);
    // 写日志函数 //
    bool WriteLog(const std::string &str, const std::string &fileName, bool utf8=true);
    bool CopyDir(const fs::path& sourcePath, const fs::path& targetPath);
};

/*********************** 弹窗 ***************************/
class WMessageBox
{
private:
    StringCode scd;

    // 标签， 内容 //
    string t;
    string c;

public:
    WMessageBox();
    void showinfo(const string title, const string content, bool utf8=true);
    void showwarning(const string title, const string content, bool utf8=true);
    void showerror(const string title, const string content, bool utf8=true);
    /* model: info warning error */
    bool askyesno(const string title, const string content, const string model="info", bool utf8=true);
};


// 异常类 //
class ImageNotFoundException : public std::exception
{
private:
    std::string message;

public:
    explicit ImageNotFoundException(const std::string& msg) : message(msg) {}
    const char* what() const noexcept override
    {
        return message.c_str();
    }
};

// 设置顶层窗口 //
class WindowTop
{
private:
    HWND hwnd; // 窗口句柄
    int px = 0;
    int py = 0;
    int w = 0;
    int h = 0;

    // 将窗口设置为顶层窗口
    void SetWindowTopMost(bool topMost);

    // 查找窗口句柄的辅助函数
    HWND FindWindowByTitle(const string& windowTitle);

    StringCode scd;

public:
    // 构造函数，指定目标窗口句柄
    explicit WindowTop(const string& hwndName, int pxc=0, int pyc=0, int wc=0, int hc=0);
    explicit WindowTop(HWND hwnd, int pxc=0, int pyc=0, int wc=0, int hc=0);

    // 开启顶层窗口
    void setWindowsTopOn();

    // 关闭顶层窗口
    void setWindowsTopOff();
};

/************* 获取类型 *************/
class __GetValueType__
{
public:
    // 检测是否为map的特征类
    template<typename T>
    struct is_std_map : std::false_type {};

    template<typename Key, typename T, typename Compare, typename Alloc>
    struct is_std_map<std::map<Key, T, Compare, Alloc>> : std::true_type {};
};


/*********************** 颜色支持 **************************/

class Color
{
private:
    int red, green, blue;
    bool isSystemColor;
    std::string colorName;

    // 将颜色名称映射到RGB值
    void mapColorNameToRGB(const std::string& name) ;


    // 解析十六进制颜色
    bool parseHexColor(const std::string& hex);


public:
    // 默认构造函数 - 无色
    Color() : red(-1), green(-1), blue(-1), isSystemColor(false) {}

    // RGB构造函数
    Color(int r, int g, int b) : red(r), green(g), blue(b), isSystemColor(false) {}

    // 颜色名称构造函数
    Color(const std::string& name) : isSystemColor(false)
    {
        if (name.empty()) {
            red = green = blue = -1;
        } else if (name[0] == '#') {
            if (!parseHexColor(name))
            {
                red = green = blue = -1;
            }
        } else {
            mapColorNameToRGB(name);
        }
    }

    // 获取Windows控制台颜色属性
    WORD getConsoleColor() const
    {
        if (red == -1) return 7; // 默认灰色

        // 简单的RGB到控制台颜色的映射
        bool bright = (red > 192 || green > 192 || blue > 192);
        int color = 0;

        if (red > 128) color |= 4;   // 红色
        if (green > 128) color |= 2; // 绿色
        if (blue > 128) color |= 1;  // 蓝色

        return color | (bright ? 8 : 0);
    }

    // 检查是否是无色（默认）
    bool isNoColor() const
    {
        return red == -1 && green == -1 && blue == -1;
    }

    // 获取RGB值
    std::tuple<int, int, int> getRGB() const
    {
        return {red, green, blue};
    }
};

namespace random
{
    // 整数随机 //
    int randint(int min, int max);
    long randint(long min, long max);
    long long randint(long long min, long long max);

    // 浮点数随机 //
    float uniform(float min, float max);
    double uniform(double min, double max);

#ifdef WkpMinGW
    // 随机选择列表容器 //
    template <class T>
    inline auto choice(vector<T> vec)
    {
        auto randomNum = randint(0, vec.size());
        return vec[randomNum];
    }

    template <class T>
    inline vector<T> choices(const std::vector<T>& population, const std::vector<double>& weights, int k = 1) {
        // 参数检查
        if (population.empty() || k <= 0)
        {
            return {};
        }

        // 如果没有提供权重，则创建均匀权重
        std::vector<double> actualWeights;
        if (weights.empty())
        {
            actualWeights.assign(population.size(), 1.0);
        } else
        {
            // 检查权重数量是否与元素数量匹配
            if (weights.size() != population.size())
            {
                throw std::invalid_argument("Weights size must match population size");
            }
            actualWeights = weights;
        }

        // 计算前缀和（累积权重）
        std::vector<double> prefixSum(population.size());
        std::partial_sum(actualWeights.begin(), actualWeights.end(), prefixSum.begin());

        // 获取总权重
        double totalWeight = prefixSum.back();

        // 如果总权重为0或无效，返回空结果
        if (totalWeight <= 0)
        {
            return {};
        }

        // 准备随机数生成器
        static std::random_device rd;
        static std::mt19937 gen(rd());
        std::uniform_real_distribution<double> dis(0.0, totalWeight);

        // 进行k次选择
        std::vector<T> result;
        result.reserve(k);

        for (int i = 0; i < k; ++i)
        {
            // 生成[0, totalWeight)之间的随机数
            double randomValue = dis(gen);

            // 使用二分查找找到第一个大于等于随机值的前缀和位置
            auto it = std::lower_bound(prefixSum.begin(), prefixSum.end(), randomValue);
            int index = std::distance(prefixSum.begin(), it);

            // 确保索引在有效范围内
            if (index >= 0 && index < population.size())
            {
                result.push_back(population[index]);
            }
        }

        return result;
    }

    // 简化版本：不需要权重的均匀选择 //
    template <class T>
    inline vector<T> choices(const std::vector<T>& population, int k = 1)
    {
        return choices(population, {}, k);
    }

#elif defined(WkpVs)
    // 随机选择列表容器 //
    template <class T>
    inline auto choice(vector<T> vec)
    {
        auto randomNum = randint(0, vec.size());
        return vec[randomNum];
    }

    // 简化版本：不需要权重的均匀选择 //
    template <class T>
    inline vector<T> choices(const std::vector<T>& population, int k = 1)
    {
        return choices(population, {}, k);
    }
#endif
}

namespace wkp
{
    // 检查已经使用管理员权限重新打开脚本 //
    bool isAdmin();
    bool openAdmin();
    // 运行时间 //
    double getRunTime();
    // 添加临时环境变量 //
    void addTempPath(const std::string& path);
    void addTempPath(const std::wstring& newPath);
    // 使用控制台编码 //
    void useConsoleUtf8();

    // 后台打开文件夹 //
    void openDir(const std::string& path, bool utf8=true);

    // 冒泡排序法 //
    // up/down//
    vector<int>sort(const int *numList, int numListSize, const string &model);
    vector<int>sort(const std::vector<int> &numList, const string &model);

    // sum列表求和 //
    int sum(std::vector<int> &numList);
    long sum(std::vector<long> &numList);
    double sum(std::vector<double> &numList);
    float sum(std::vector<float> &numList);

    // 获取当前时间 //
    string getNowTime();

    // 延迟 //
    void sleep(double delay);

    // 获取当前exe路径 //
    std::string getExePath(bool useWindows=false);

    // 获取变量类型 //
    template<typename Types>
    string typeName(Types type);

    // 字符串影射 //
    // 安全的字符串格式化函数（替代 fmt::format）
    std::string string_format(const char* format, ...);

    /***************** 进程杀死 *****************/
    bool KillProcess(const fs::path &processName);

    /*************** println和print ****************/
    // println //
    template<typename T, typename... Args>
    void println(const T &first, const Args &...rest);
    // 颜色输出println //
    template<typename T, typename... Args>
    void println(const Color &colors, const T &first, const Args &...rest);

    // 智能判断输出模式的 print 函数（不换行） //
    template<typename T, typename... Args>
    void print(const T& first, const Args&... rest);
    // 颜色输出print //
    template<typename T, typename... Args>
    void print(const Color &colors, const T &first, const Args &...rest);

    // 获取控制台编码 utf8, gbk, big5 //
    string getConsoleEncoding();

    // 开机自启 //
    bool setAutoStartUp(const std::string &appName, bool isUtf8=true);
    bool setAutoStartUp(const std::string &exePath, const std::string &appName, bool isUtf8=true);

    // 禁止开机自启 //
    bool disableAutoStart(const string& appName, bool isUtf8=true);

    bool callPowerShell(const string& cmd);

    void setAutoDpi();

    // 获取文件列表 //
    vector<string> listDir(const string& path);

    // 开启其他软件 //
    bool startOtherApp(const string& appPath);

    // 获取注册表键值 //
    string getRegistryPath(const std::string &keyPath, const std::string &valueName);
    // 获取变量类型 //
    template<typename Types>
    string typeName(Types type);

    /************ format映射 ************/
    // 最终函数 //
    template<typename... Args>
    std::string format(const std::string& fmt, Args&&... args);

    /**************** 字典 ****************/
    template<typename Key, typename Value>
    class Dict
    {
    private:
        using KeyValuePair = std::pair< Key, Value>;
        using ListType = std::list<KeyValuePair>;
        using MapType = std::unordered_map<Key, typename ListType::iterator>;

        ListType order_list;  // 维护插入顺序的链表
        MapType lookup_map;   // 提供快速查找的哈希表

        std::vector<Key> keyList;
        std::vector<Value> valueList;

    public:
        // 重载 operator[] 以支持 dict[key] = value 语法 //
        Value& operator[](const Key& key)
        {
            auto it = lookup_map.find(key);
            if (it != lookup_map.end())
            {
                // 键已存在：返回对应值的引用（用于赋值）
                return it->second->second;
            }
            else
            {
                // 键不存在：插入新键值对（值默认初始化），并返回值的引用
                order_list.push_back({key, Value{}});
                auto list_iter = --order_list.end();
                lookup_map[key] = list_iter;
                return list_iter->second;
            }
        }

        // 新增：const版本 operator[] (用于读取)
        const Value& operator[](const Key& key) const
        {
            auto it = lookup_map.find(key);
            if (it != lookup_map.end())
            {
                return it->second->second;
            }
            else
            {
                // 键不存在时抛出异常（或者返回默认值）
                throw std::out_of_range("Key not found in dictionary");
            }
        }

        // 可选：添加安全的 get 方法，避免异常
        Value get(const Key& key, const Value& defaultValue = Value{}) const
        {
            auto it = lookup_map.find(key);
            if (it != lookup_map.end())
            {
                return it->second->second;
            }
            return defaultValue;
        }

        // 插入或更新键值对 //
        inline void insert(const Key& key, const Value& value)
        {
            (*this)[key] = value; // 复用 operator[]
        }

        // 删除键值对 //
        inline bool pop(const Key& key)
        {
            auto it = lookup_map.find(key);
            if (it != lookup_map.end())
            {
                order_list.erase(it->second); // 从链表删除
                lookup_map.erase(it);         // 从哈希表删除
                return true;
            }
            return false;
        }

        // 返回用于范围循环的 items 视图（支持结构化绑定） //
        inline auto items() const
        {
            return order_list; // 直接返回链表，其迭代器解引用为 std::pair<const Key, Value>
        }

        inline auto keys() const
        {
            std::vector<Key> keyList;
            for (const auto& pair : order_list) {
                keyList.push_back(pair.first);
            }
            return keyList;
        }

        // 修复 values() 方法
        auto values() const
        {
            std::vector<Value> valueList;
            for (const auto& pair : order_list) {
                valueList.push_back(pair.second);
            }
            return valueList;
        }

        // 字典转为字符串 //
        std::string dictToString();

        // 其他常用方法
        inline size_t size() const { return order_list.size(); }
        inline bool empty() const { return order_list.empty(); }

        inline void clear()
        {
            order_list.clear();
            lookup_map.clear();
        }
    };

    // Open类读写文件 //
    /**
     open函数有r,rb,w,wb,a等模式读写文件，并且默认自动关闭文件，在离开作用域之后，带bin的函数需要以
     rb/wb/ab进行读取与写入，反之之间使用正常的w，b，a即可
     **/
    class Open
    {
    private:
        // 读写文件 //
        std::ifstream ipt;
        std::ofstream opt;
        // 文件模式 //
        string filePath;
        string model;

        bool ipt_isOpen = false;
        bool opt_isOpen = false;
        bool autoCloseFile = true;

        StringCode scd;
    private:

        // 简单的 XOR 加密密钥 //
        const std::vector<unsigned char> encryptionKey = {0xAB, 0xCD, 0xEF, 0x12, 0x34, 0x56, 0x78, 0x90};

        // XOR 加密/解密函数
        inline void xorEncryptDecrypt(std::vector<unsigned char>& data)
        {
            for (size_t i = 0; i < data.size(); ++i) {
                data[i] ^= encryptionKey[i % encryptionKey.size()];
            }
        }

        // 函数：将字符串转换为二进制数据（vector<unsigned char>） //
        void _stringToBinary(const std::string& str, std::vector<unsigned char>& binData);
        // 函数：将二进制数据写入文件（以二进制模式） //
        void _writeBinaryToFile(const std::vector<unsigned char>& binData, const std::string& filename);
        // 函数：从文件读取二进制数据 //
        void _readBinaryFromFile(const std::string& filename, std::vector<unsigned char>& binData);
        // 函数：将二进制数据转换回字符串（用于验证 //）
        void _binaryToString(const std::vector<unsigned char>& binData, std::string& str);

    public:
        // 默认构造函数 //
        Open() = default;
        Open(const string &file_path, const string &file_mode, bool isUtf8=true, bool auto_close=true);
        // 打开文件 //
        void open(const string &file_path, const string &file_mode, bool isUtf8=true, bool auto_close=true);
        // 检查是否成功打开 //
        bool isOpen();

        // 读取文件 //
        string read();
        vector<string> readLine();
        // 二进制读取文件 //
        std::vector<unsigned char> readBinary();
        // 读取json //
        Dict<string,string> readJson();
        // 二进制文件转字符串 //
        string readBinaryToString();

        // 写入文件 //
        void write(const string &str);
        // 写入二进制文件 //
        void writeBinary(const std::vector<unsigned char> &data);
        // 写入json //
        template<class K, class V>
        void writeJson(Dict<K, V> dicts);
        // 字符串转二进制 //
        void writeStringToBinary(const string &str);


        // 关闭文件 //
        void close();

        ~Open();
    };

    Dict<string, string> stringToJson(const std::string& jsonStr);
}

#ifdef WkpMinGW
    namespace re
    {
        enum ReFlags {
            IGNORECASE = 1, I = 1, MULTILINE = 2, M = 2,  NOMODEL= 0
        };
        vector<string>findall(const string &pattern, const string &text, int flags=NOMODEL);
        string search(const string &pattern, const string &text, int flags=NOMODEL);
        string sub(const string &pattern, const string &repl, const string &text, int flags=NOMODEL);
        // 支持回调函数的sub版本
        string sub(const string &pattern,std::function<string(const std::smatch&)>
        callback,const string &text,int flags = NOMODEL);
    }
#elif defined(WkpVs)
    namespace re
    {
        enum ReFlags {
            IGNORECASE = 1, I = 1, MULTILINE = 2, M = 2, NOMODEL = 0
        };

        vector<string> findall(const string& pattern, const string& text, int flags = NOMODEL);

        string search(const string& pattern, const string& text, int flags = NOMODEL);

        string sub(const string& pattern, const string& repl, const string& text, int flags = NOMODEL);

        string sub(const string& pattern, std::function<string(const std::smatch&)> callback,
                   const string& text, int flags = NOMODEL);
    }
#endif

/******************* 字符串转字典 *******************/
class StringToDictClass
{
public:
    // 工具函数：去除字符串两端的空白字符 //
    inline std::string trim(const std::string& str)
    {
        size_t start = str.find_first_not_of(" \t\n\r");
        if (start == std::string::npos) return "";
        size_t end = str.find_last_not_of(" \t\n\r");
        return str.substr(start, end - start + 1);
    }

    // 解析字符串值（去除引号） //
    inline std::string parseString(std::string& str)
    {
        str = trim(str);
        if (str.front() == '"' && str.back() == '"')
        {
            return str.substr(1, str.length() - 2);
        }
        return str;
    }

    // 解析数字值 //
    inline int parseNumber(const std::string& str)
    {
        return std::stoi(trim(str));
    }

    // 解析 JSON 对象 //
    template<typename KeyType, typename ValueType>
    wkp::Dict<KeyType, ValueType> parseObject(std::string& jsonStr)
    {
        wkp::Dict<KeyType, ValueType> result;

        // 去除外层花括号
        jsonStr = trim(jsonStr);
        if (jsonStr.front() == '{' && jsonStr.back() == '}') {
            jsonStr = jsonStr.substr(1, jsonStr.length() - 2);
        }

        size_t pos = 0;
        while (pos < jsonStr.length()) {
            // 查找键
            size_t keyStart = jsonStr.find('"', pos);
            if (keyStart == std::string::npos) break;

            size_t keyEnd = jsonStr.find('"', keyStart + 1);
            if (keyEnd == std::string::npos) break;

            std::string key = jsonStr.substr(keyStart + 1, keyEnd - keyStart - 1);

            // 查找值开始位置（冒号后）
            size_t valueStart = jsonStr.find(':', keyEnd + 1);
            if (valueStart == std::string::npos) break;
            valueStart++; // 跳过冒号

            // 查找值结束位置
            size_t valueEnd = valueStart;
            int braceCount = 0;
            bool inString = false;

            while (valueEnd < jsonStr.length()) {
                char c = jsonStr[valueEnd];

                if (c == '"' && (valueEnd == 0 || jsonStr[valueEnd - 1] != '\\')) {
                    inString = !inString;
                } else if (!inString) {
                    if (c == '{') braceCount++;
                    else if (c == '}') braceCount--;
                    else if (c == ',' && braceCount == 0) break;
                }

                valueEnd++;
                if (valueEnd == jsonStr.length()) break;
            }

            std::string valueStr = jsonStr.substr(valueStart, valueEnd - valueStart);
            valueStr = trim(valueStr);

            // 根据值类型解析
            if (valueStr.front() == '{') {
                // 嵌套对象
                auto nestedDict = parseObject<KeyType, ValueType>(valueStr);
                // 这里需要根据你的 Dict 类实现来调整
                result[key] = valueStr; // 简化处理，实际应该存储解析后的字典
            } else if (valueStr.front() == '"') {
                // 字符串值
                result[key] = parseString(valueStr);
            } else {
                // 数字值
                result[key] = std::to_string(parseNumber(valueStr));
            }

            pos = valueEnd + 1;
        }

        return result;
    }
};


/********************* 末尾实现 *********************/
// 按下快捷键 //
template<typename... Args>
void KeyBoardEvent::PressHotKey(const std::string& first, Args... rest)
{
    KeyDown(first);       // 按下当前键
    PressHotKey(rest...); // 递归处理剩余键
    KeyUp(first);         // 递归返回后释放当前键（逆序释放）
}

// 类型输出 //
// 获取变量类型 //
template<typename Types>
string wkp::typeName(Types type)
{
    auto temp_type = typeid(type).name();
    string type_name = temp_type;

    // 字符串部分 //
    string str_type = typeid(string).name();
    string c_str_type = typeid(const char *).name();
    string wc_str_type = typeid(wchar_t *).name();
    string w_str_type = typeid(std::wstring).name();

    //字符部分 //
    string char_type = typeid(char).name();
    string wchar_t_type = typeid(wchar_t).name();

    string unsigned_char = typeid(unsigned char).name();

    // 数字部分 //
    string int_type = typeid(int).name();
    string short_type = typeid(short).name();
    string long_type = typeid(long).name();
    string long_long_type = typeid(long long).name();

    string unsigned_int_type = typeid(unsigned int).name();
    string unsigned_short_type = typeid(unsigned short).name();
    string unsigned_long_type = typeid(unsigned long).name();
    string unsigned_long_long_type = typeid(unsigned long long).name();

    // 数组部分 //
    string int_arr_type = typeid(int *).name();
    string short_arr_type = typeid(short *).name();
    string long_arr_type = typeid(long *).name();
    string long_long_arr_type = typeid(long long *).name();

    string unsigned_int_arr_type = typeid(unsigned int *).name();
    string unsigned_short_arr_type = typeid(unsigned short *).name();
    string unsigned_long_arr_type = typeid(unsigned long *).name();
    string unsigned_long_long_arr_type = typeid(unsigned long long *).name();

    // 浮点数部分 //
    string double_type = typeid(double).name();
    string float_type = typeid(float).name();

    string double_arr_type = typeid(double *).name();
    string float_arr_type = typeid(float *).name();

    // 布尔类型部分 //
    string bool_type = typeid(bool).name();

    // vector字符与字符串 //
    string vector_char = typeid(vector<char>).name();
    string vector_string = typeid(vector<string>).name();

    string vector_unsigned_char = typeid(vector<unsigned char>).name();

    // 整数部分 //
    string vector_int = typeid(vector<int>).name();
    string vector_short = typeid(vector<short>).name();
    string vector_long = typeid(vector<long>).name();
    string vector_long_long = typeid(vector<long long>).name();

    string vector_unsigned_int = typeid(vector<unsigned int>).name();
    string vector_unsigned_short = typeid(vector<unsigned short >).name();
    string vector_unsigned_long = typeid(vector<unsigned long>).name();
    string vector_unsigned_long_long = typeid(vector<unsigned long long>).name();

    // 浮点数部分 //
    string vector_double = typeid(vector<double>).name();
    string vector_float = typeid(vector<float>).name();

    // 字符 //
    if (type_name == str_type)
    {
        return "string";
    }
    else if (type_name == char_type)
    {
        return "char";
    }
    else if (type_name == c_str_type)
    {
        return "c_str";
    }
    else if(type_name == unsigned_char)
    {
        return "unsigned_char";
    }
        // vector //
    else if (type_name == vector_int)
    {
        return "vector_int";
    }
    else if (type_name == vector_char)
    {
        return "vector_char";
    }
    else if (type_name == vector_string)
    {
        return "vector_string";
    }
    else if (type_name == vector_double)
    {
        return "vector_double";
    }
    else if (type_name == vector_float)
    {
        return "vector_float";
    }
    else if (type_name == vector_unsigned_char)
    {
        return "vector_unsigned_char";
    }
    else if (type_name == vector_unsigned_int)
    {
        return "vector_unsigned_int";
    }
    else if (type_name == vector_unsigned_long)
    {
        return "vector_unsigned_long";
    }
    else if (type_name == vector_unsigned_short)
    {
        return "vector_unsigned_short";
    }
    else if (type_name == vector_unsigned_long_long)
    {
        return "vector_unsigned_long_long";
    }
    else if (type_name == vector_short)
    {
        return "vector_short";
    }
    else if (type_name == vector_long)
    {
        return "vector_long";
    }
    else if (type_name == vector_long_long)
    {
        return "vector_long_long";
    }
        // 宽字符 //
    else if (type_name == wchar_t_type)
    {
        return "wchar_t";
    }
    else if(type_name == wc_str_type)
    {
        return "wc_str";
    }
    else if (type_name == w_str_type)
    {
        return "w_str";
    }
        // 数字 //
    else if (type_name == int_type)
    {
        return "int";
    }
    else if (type_name == double_type)
    {
        return "double";
    }
    else if (type_name == float_type)
    {
        return "float";
    }
    else if (type_name == long_type)
    {
        return "long";
    }
    else if (type_name == long_long_type)
    {
        return "long_long";
    }
    else if (type_name == short_type)
    {
        return "short";
    }
    else if (type_name == unsigned_int_type)
    {
        return "unsigned_int";
    }
    else if (type_name == unsigned_long_type)
    {
        return "unsigned_long";
    }
    else if (type_name == unsigned_short_type)
    {
        return "unsigned_short";
    }
    else if (type_name == unsigned_long_long_type)
    {
        return "unsigned_long_long";
    }
        // 布尔 //
    else if (type_name == bool_type)
    {
        return "bool";
    }
        // 数组 //
    else if (type_name == int_arr_type)
    {
        return "int_arr";
    }
    else if(type_name == long_arr_type)
    {
        return "long_arr";
    }
    else if (type_name == long_long_arr_type)
    {
        return "long_long_arr";
    }
    else if (type_name == short_arr_type)
    {
        return "short_arr";
    }
    else if (type_name == unsigned_int_arr_type)
    {
        return "unsigned_int_arr";
    }
    else if (type_name == unsigned_short_arr_type)
    {
        return "unsigned_short_arr_type";
    }
    else if (type_name == unsigned_long_arr_type)
    {
        return "unsigned_long_arr";
    }
    else if (type_name == unsigned_long_long_arr_type)
    {
        return "unsigned_long_long_arr";
    }
    else if (type_name == double_arr_type)
    {
        return "double_arr";
    }
    else if (type_name == float_arr_type)
    {
        return "float_arr";
    }

    // 检查类型是否为map //
    if constexpr (__GetValueType__::is_std_map<Types>::value)
    {
        return "map";
    }

    // 检查类或者结构体 //
    if constexpr (std::is_class_v<Types>)
    {
        if constexpr (std::is_aggregate_v<Types>)
        {
//            std::cout << typeid(Types).name() << " 是一个结构体\n";
            return "struct";
        } else
        {
//            std::cout << typeid(Types).name() << " 是一个类\n";
            return "class";
        }
    }

    return "";
}

/***************** 映射字符串 *****************/
class FormatWkp
{
public:
    std::string format(const char* fmt);

    template<typename T, typename... Args>
    std::string format(const char* fmt, T&& value, Args&&... args);

    // 辅助函数，支持std::string作为格式字符串
    template<typename... Args>
    std::string format(const std::string& fmt, Args&&... args);

    // 布尔处理函数 //
    std::string my_to_string(bool boolType);

    // 基础类型的 my_to_string 重载 //
    template<typename T>
    std::string my_to_string(const T& value);

    // 处理 vector类型 //
    template<typename T>
    std::string my_to_string(const std::vector<T>& vec);

    // 数组特化版本 //
    template<typename T, size_t N>
    std::string my_to_string(const T (&arr)[N]);

    // 指针数组版本 //
    template<typename T>
    std::string my_to_string(const T* arr, size_t size);

    // dict类型检查 - 修复版本 //
    template<typename K, typename V>
    std::string my_to_string(wkp::Dict<K, V> dict);

    // map类型设置 //
    template<typename K, typename V>
    std::string my_to_string(std::map<K, V> mp);
};

/************ Print类 ************/
class Print
{
private:
    static Color currentColor;
    static std::vector<Color> colorStack;

public:
    bool printDebugFlag = false;
    // 布尔值判断 //
    inline std::string my_to_string(bool boolType)
    {
        return boolType?"true":"false";
    }
    // 基础情况：处理单个参数到字符串的转换 //
    template<typename T>
    std::string my_to_string(const T& arg);

    // map类型设置 //
    template<typename K, typename V>
    std::string my_to_string(std::map<K, V> mp);

    // dict类型检查 //
    template<typename K, typename V>
    std::string my_to_string(wkp::Dict<K, V> dict);

    // 在 Print 类中添加数组特化版本 //
    template<typename T, size_t N>
    std::string my_to_string(const T (&arr)[N]);

    // 或者使用模板特化 //
    template<typename T>
    std::string my_to_string(const T* arr, size_t size);

    // 对 std::string 的特殊处理，避免不必要的转换 //
    inline std::string my_to_string(const std::string& arg)
    {
        return arg;
    }

    // 对字符串字面量的特殊处理 //
    inline std::string my_to_string(const char* const& arg)
    {
        return std::string(arg);
    }

    // 处理 vector 类型 //
    template<typename T>
    std::string my_to_string(const std::vector<T>& vec);

    // 检查字符串中花括号的数量 //
    std::pair<size_t, bool> count_braces(const std::string& str);

    // 核心函数：识别花括号并替换参数 //
    template<typename... Args>
    std::string my_format(const std::string& fmt_str, const Args&... args);

    // 简单的顺序输出所有参数 //
    template<typename... Args>
    std::string simple_print(const Args&... args);

    // 设置颜色（不影响现有接口） //
    static void setColor(const Color& color);

    // 重置颜色 //
    static void resetColor();

    // 压入颜色（用于嵌套） //
    static void pushColor(const Color& color);
    // 弹出颜色 //
    static void popColor();
};

// 内部声明 //
static Print __pnt__;


/*********************** 颜色文本包装器 **************************/
class __ColoredText__
{
private:
    std::string text;
    Color color;

public:
    __ColoredText__(const std::string& str, const Color& col) : text(str), color(col) {}
    __ColoredText__(const char* str, const Color& col) : text(str), color(col) {}

    template<typename T>
    __ColoredText__(const T& value, const Color& col) : text(__pnt__.my_to_string(value)), color(col) {}

    const std::string& getText() const { return text; }
    const Color& getColor() const { return color; }

    // 添加友元函数用于输出
    friend std::ostream& operator<<(std::ostream& os, const __ColoredText__& ct) {
        os << ct.text;
        return os;
    }
};

namespace color
{
    // 辅助函数，便于创建彩色文本
    inline __ColoredText__ printColor(const std::string& text, const Color& color)
    {
        return __ColoredText__(text, color);
    }

    template<typename T>
    inline __ColoredText__ printColor(const T& value, const Color& color) {
        return ColoredText(value, color);
    }
}


/************** Format **************/
// 递归情况：处理参数包 //
template<typename T, typename... Args>
std::string FormatWkp::format(const char* fmt, T&& value, Args&&... args)
{
    std::ostringstream result;
    bool placeholder_found = false;

    // 遍历格式字符串
    for (const char* p = fmt; *p != '\0'; ++p)
    {
        if (*p == '{' && *(p+1) == '}')
        {
            // 找到占位符，插入当前参数值（使用 my_to_string 转换）
            result << my_to_string(value);
            placeholder_found = true;

            // 递归处理剩余参数和格式字符串
            if (*(p+2) != '\0')
            {
                result << format(p+2, std::forward<Args>(args)...);
            } else if (sizeof...(args) > 0)
            {
                throw std::logic_error("提供的参数数量多于格式字符串中的占位符");
            }
            break;
        } else
        {
            // 普通字符，直接复制
            result << *p;
        }
    }

    // 如果没有找到占位符但有剩余参数，报错
    if (!placeholder_found && sizeof...(args) > 0)
    {
        throw std::logic_error("格式字符串中没有足够的占位符");
    }

    return result.str();
}

// 辅助函数，支持std::string作为格式字符串 //
template<typename... Args>
std::string FormatWkp::format(const std::string& fmt, Args&&... args)
{
    return format(fmt.c_str(), std::forward<Args>(args)...);
}

// 基础类型的 my_to_string 重载 - 这是关键！ //
template<typename T>
std::string FormatWkp::my_to_string(const T& value)
{
    // 对于基础类型，使用 ostringstream 直接转换 //
    std::ostringstream oss;
    oss << value;
    return oss.str();
}

// 处理 vector 类型 //
template<typename T>
std::string FormatWkp::my_to_string(const std::vector<T>& vec)
{
    if (vec.empty())
    {
        return "[]";
    }

    std::ostringstream oss;
    oss << "[";

    for (size_t i = 0; i < vec.size(); ++i)
    {
        // 直接使用通用的 my_to_string 转换每个元素
        oss << my_to_string(vec[i]);

        if (i < vec.size() - 1) {
            oss << ", ";
        }
    }
    oss << "]";
    return oss.str();
}

// 数组特化版本 //
template<typename T, size_t N>
std::string FormatWkp::my_to_string(const T (&arr)[N])
{

    std::ostringstream oss;
    auto type = wkp::typeName(arr[0]);
    bool isStr = false;
    if (type == "c_str" || type == "string")
    {
        isStr = true;
    }
    oss << "[";
    for (size_t i = 0; i < N; ++i)
    {
        string str = isStr? format(R"("{}")", arr[i]): my_to_string(arr[i]);
        oss << str;  // 递归调用
        if (i < N - 1) oss << ", ";
    }
    oss << "]";
    return oss.str();
}

// 指针数组版本 //
template<typename T>
std::string FormatWkp::my_to_string(const T* arr, size_t size)
{
    std::ostringstream oss;
    oss << "[";
    for (size_t i = 0; i < size; ++i)
    {
        oss << my_to_string(arr[i]);  // 递归调用
        if (i < size - 1) oss << ", ";
    }
    oss << "]";
    return oss.str();
}

// dict类型检查 - 修复版本 //
template<typename K, typename V>
std::string FormatWkp::my_to_string(wkp::Dict<K, V> dict)
{
    if (dict.empty())
    {
        return "{}";
    }
    std::ostringstream oss;
    bool k_isStr = false;
    bool v_isStr = false;

    // 获取第一个元素来判断类型
    auto keys = dict.keys();
    auto values = dict.values();

    if (keys.empty() || values.empty()) {
        return "{}";
    }

    // 使用第一个元素来判断类型
    auto first_key_type = wkp::typeName(keys[0]);
    auto first_value_type = wkp::typeName(values[0]);

    k_isStr = (first_key_type == "string") ||
              (first_key_type == "c_str") ||
              (first_key_type == "char");

    v_isStr = (first_value_type == "string") ||
              (first_value_type == "c_str") ||
              (first_value_type == "char");

    oss << "{";
    int tempCount = 0;
    for (auto &[k, v] : dict.items())
    {
        // 处理键
        if (k_isStr) {
            oss << "\"" << __pnt__.my_to_string(k) << "\"";
        } else {
            oss << __pnt__.my_to_string(k);
        }

        oss << ": ";

        // 处理值
        if (v_isStr) {
            oss << "\"" << __pnt__.my_to_string(v) << "\"";
        } else {
            oss << __pnt__.my_to_string(v);
        }

        // 添加逗号分隔（最后一个元素不加）
        if (tempCount < dict.size() - 1) {
            oss << ", ";
        }
        tempCount++;
    }
    oss << "}";
    return oss.str();
}

// map类型设置 - 修复版本
template<typename K, typename V>
std::string FormatWkp::my_to_string(std::map<K, V> mp)
{
    if (mp.empty()) {
        return "{}";
    }

    std::ostringstream oss;
    bool k_isStr = false;
    bool v_isStr = false;

    // 使用 begin() 获取指向第一个元素的迭代器
    auto first_element = mp.begin();

    // 安全地检查键和值的类型
    std::string first_key_str = __pnt__.my_to_string(first_element->first);
    std::string first_value_str = __pnt__.my_to_string(first_element->second);

    // 检查键和值是否需要引号（基于第一个元素的类型推断）
    k_isStr = (wkp::typeName(first_element->first) == "string") ||
              (wkp::typeName(first_element->first) == "c_str") ||
              (wkp::typeName(first_element->first) == "char");

    v_isStr = (wkp::typeName(first_element->second) == "string") ||
              (wkp::typeName(first_element->second) == "c_str") ||
              (wkp::typeName(first_element->second) == "char");

    oss << "{";
    int tempCount = 0;
    for (auto it = mp.begin(); it != mp.end(); ++it)
    {
        // 处理键
        if (k_isStr) {
            oss << "\"" << __pnt__.my_to_string(it->first) << "\"";
        } else {
            oss << __pnt__.my_to_string(it->first);
        }

        oss << ": ";

        // 处理值
        if (v_isStr) {
            oss << "\"" << __pnt__.my_to_string(it->second) << "\"";
        } else {
            oss << __pnt__.my_to_string(it->second);
        }

        // 添加逗号分隔（最后一个元素不加）
        if (tempCount < mp.size() - 1) {
            oss << ", ";
        }
        tempCount++;
    }
    oss << "}";
    return oss.str();
}


/**************** print ****************/
template<typename T>
std::string Print::my_to_string(const T& arg)
{
    std::ostringstream oss;
    oss << arg;
    return oss.str();
}

// dict类型检查 - 修复版本 //
// 在 Print 类中修改 my_to_string 方法
template<typename K, typename V>
std::string Print::my_to_string(wkp::Dict<K, V> dict)
{
    if (dict.empty())
    {
        return "{}";
    }

    std::ostringstream oss;
    bool k_isStr = false;
    bool v_isStr = false;
    bool v_isDict = false;

    // 获取第一个元素来判断类型
    auto keys = dict.keys();
    auto values = dict.values();

    if (keys.empty() || values.empty()) {
        return "{}";
    }

    // 使用第一个元素来判断类型
    auto first_key_type = wkp::typeName(keys[0]);
    auto first_value_type = wkp::typeName(values[0]);

    k_isStr = (first_key_type == "string") ||
              (first_key_type == "c_str") ||
              (first_key_type == "char");

    v_isStr = (first_value_type == "string") ||
              (first_value_type == "c_str") ||
              (first_value_type == "char");

    // 新增：检查是否为嵌套字典
    v_isDict = (first_value_type.find("Dict") != std::string::npos) ||
               (first_value_type == "struct") ||  // Dict 可能被识别为 struct
               (first_value_type == "class");    // 或者 class

    oss << "{";
    int tempCount = 0;

    for (auto &[k, v] : dict.items())
    {
        // 处理键
        if (k_isStr) {
            oss << "\"" << __pnt__.my_to_string(k) << "\"";
        } else {
            oss << __pnt__.my_to_string(k);
        }

        oss << ":";

        // 处理值 - 新增嵌套字典支持
        if (v_isStr) {
            oss << "\"" << __pnt__.my_to_string(v) << "\"";
        }
        else if (v_isDict) {
            // 递归处理嵌套字典
            try {
                // 尝试将值作为字典处理
                oss << __pnt__.my_to_string(v);
            }
            catch (...) {
                // 如果转换失败，使用普通方式处理
                oss << __pnt__.my_to_string(v);
            }
        }
        else {
            oss << __pnt__.my_to_string(v);
        }

        // 添加逗号分隔（最后一个元素不加）
        if (tempCount < dict.size() - 1) {
            oss << ", ";
        }
        tempCount++;
    }
    oss << "}";
    return oss.str();
}

// map类型设置 //
// map类型设置 - 修复版本
template<typename K, typename V>
std::string Print::my_to_string(std::map<K, V> mp)
{
    if (mp.empty()) {
        return "{}";
    }

    std::ostringstream oss;
    bool k_isStr = false;
    bool v_isStr = false;

    // 使用 begin() 获取指向第一个元素的迭代器
    auto first_element = mp.begin();

    // 安全地检查键和值的类型
    std::string first_key_str = __pnt__.my_to_string(first_element->first);
    std::string first_value_str = __pnt__.my_to_string(first_element->second);

    // 检查键和值是否需要引号（基于第一个元素的类型推断）
    k_isStr = (wkp::typeName(first_element->first) == "string") ||
              (wkp::typeName(first_element->first) == "c_str") ||
              (wkp::typeName(first_element->first) == "char");

    v_isStr = (wkp::typeName(first_element->second) == "string") ||
              (wkp::typeName(first_element->second) == "c_str") ||
              (wkp::typeName(first_element->second) == "char");

    oss << "{";
    int tempCount = 0;
    for (auto it = mp.begin(); it != mp.end(); ++it)
    {
        // 处理键
        if (k_isStr) {
            oss << "\"" << __pnt__.my_to_string(it->first) << "\"";
        } else {
            oss << __pnt__.my_to_string(it->first);
        }

        oss << ": ";

        // 处理值
        if (v_isStr) {
            oss << "\"" << __pnt__.my_to_string(it->second) << "\"";
        } else {
            oss << __pnt__.my_to_string(it->second);
        }

        // 添加逗号分隔（最后一个元素不加）
        if (tempCount < mp.size() - 1) {
            oss << ", ";
        }
        tempCount++;
    }
    oss << "}";
    return oss.str();
}

// 在 Print 类中添加数组特化版本 //
template<typename T, size_t N>
std::string Print::my_to_string(const T (&arr)[N])
{
    std::ostringstream oss;
    auto type = wkp::typeName(arr[0]);
    oss << "[";
    for (size_t i = 0; i < N; ++i)
    {
        if (type == "string" || type == "c_str")
        {
            auto temp = wkp::format(R"("{}")", arr[i]);
            oss << my_to_string(temp);
        }
        else if (type == "char")
        {
            auto temp = wkp::format(R"('{}')", arr[i]);
            oss << my_to_string(temp);
        }
        else
        {
            oss << my_to_string(arr[i]);
        }
        if (i < N - 1) oss << ", ";
    }
    oss << "]";
    return oss.str();
}

// 或者使用模板特化 //
template<typename T>
std::string Print::my_to_string(const T* arr, size_t size)
{
    std::ostringstream oss;
    string type = wkp::typeName(arr[0]);
    oss << "[";
    for (size_t i = 0; i < size; ++i)
    {
        if (type == "string" || type == "c_str")
        {
            auto temp = wkp::format(R"("{}")", arr[i]);
            oss << my_to_string(temp);
        }
        else if (type == "char")
        {
            auto temp = wkp::format(R"('{}')", arr[i]);
            oss << my_to_string(temp);
        }
        else
        {
            oss << my_to_string(arr[i]);
        }
        if (i < size - 1) oss << ", ";
    }
    oss << "]";
    return oss.str();
}

template<typename T>
std::string Print::my_to_string(const std::vector<T>& vec)
{
    bool vectorIsNull = vec.empty();
    if (!vectorIsNull)
    {
        std::ostringstream oss;
        auto type = wkp::typeName(vec[0]);
        oss << "[";
        for (size_t i = 0; i < vec.size(); ++i)
        {
            if (type == "string" || type == "c_str")
            {
                auto temp = wkp::format(R"("{}")", vec[i]);
                oss << my_to_string(temp);
            }
            else if (type == "char")
            {
                auto temp = wkp::format(R"('{}')", vec[i]);
                oss << my_to_string(temp);
            }
            else
            {
                oss << my_to_string(vec[i]);
            }
            if (i < vec.size() - 1)
            {
                oss << ", ";
            }
        }
        oss << "]";
        return oss.str();
    }
    return "[]";
}

// 简单的顺序输出所有参数
template<typename... Args>
std::string Print::simple_print(const Args&... args)
{
    std::ostringstream result;
    size_t count = 0;
    size_t total = sizeof...(args);

    auto print_arg = [&](const auto& arg)
    {
        result << my_to_string(arg);
        if (++count < total) {
            result << " ";
        }
    };

    (print_arg(args), ...); // C++17 折叠表达式
    return result.str();
}

// 核心函数：识别花括号并替换参数 //
template<typename... Args>
std::string Print::my_format(const std::string& fmt_str, const Args&... args)
{
    std::vector<std::string> arg_strings = {my_to_string(args)...};
    size_t arg_index = 0;
    size_t arg_count = sizeof...(args);

    std::ostringstream result;
    size_t pos = 0;
    size_t len = fmt_str.length();

    while (pos < len)
    {
        // 查找下一个花括号
        size_t open_brace = fmt_str.find('{', pos);

        if (open_brace == std::string::npos)
        {
            // 没有找到更多花括号，输出剩余部分
            result << fmt_str.substr(pos);
            break;
        }

        // 输出花括号之前的内容
        result << fmt_str.substr(pos, open_brace - pos);

        // 检查是否是转义的 {{
        if (open_brace + 1 < len && fmt_str[open_brace + 1] == '{')
        {
            result << '{';
            pos = open_brace + 2;
            continue;
        }

        // 查找对应的闭合花括号
        size_t close_brace = fmt_str.find('}', open_brace + 1);
        if (close_brace == std::string::npos)
        {
            throw std::runtime_error("Unmatched '{' in format string");
        }

        // 检查是否是转义的 }}
        if (close_brace + 1 < len && fmt_str[close_brace + 1] == '}')
        {
            result << '}';
            pos = close_brace + 2;
            continue;
        }

        // 检查花括号内容是否为空（即 {}）
        if (close_brace == open_brace + 1)
        {
            // 这是一个空的 {} 占位符
            if (arg_index >= arg_count)
            {
                throw std::runtime_error("Too few arguments for format string");
            }

            result << arg_strings[arg_index];
            arg_index++;
            pos = close_brace + 1;
        }
        else
        {
            // 花括号内有内容，暂时不支持格式化选项
            // 可以在这里添加对 {index} 或 {key} 的支持
            std::string placeholder = fmt_str.substr(open_brace + 1, close_brace - open_brace - 1);

            // 如果是数字索引，如 {0}, {1}
            try {
                size_t index = std::stoul(placeholder);
                if (index >= arg_count)
                {
                    throw std::runtime_error("Argument index out of range");
                }
                result << arg_strings[index];
                pos = close_brace + 1;
            }
            catch (const std::exception&) {
                // 不是数字索引，按顺序处理
                if (arg_index >= arg_count)
                {
                    throw std::runtime_error("Too few arguments for format string");
                }
                result << arg_strings[arg_index];
                arg_index++;
                pos = close_brace + 1;
            }
        }
    }

    // 检查是否所有参数都被使用
    if (arg_index < arg_count)
    {
        throw std::runtime_error("Too many arguments for format string");
    }

    return result.str();
}

/************** 字典转为字符串实现 **************/
// 在类外正确定义 dictToString 函数
template<typename Key, typename Value>
std::string wkp::Dict<Key, Value>::dictToString()
{
    if (this->empty())
    {
        return "{}";
    }

    std::ostringstream oss;
    bool k_isStr = false;
    bool v_isStr = false;
    bool v_isDict = false;

    // 获取字典的键值对来判断类型
    auto keys = this->keys();
    auto values = this->values();

    if (keys.empty() || values.empty()) {
        return "{}";
    }

    // 使用第一个元素来判断类型
    auto first_key_type = wkp::typeName(keys[0]);
    auto first_value_type = wkp::typeName(values[0]);

    // 判断键是否需要引号
    k_isStr = (first_key_type == "string") ||
              (first_key_type == "c_str") ||
              (first_key_type == "char");

    // 判断值是否需要引号
    v_isStr = (first_value_type == "string") ||
              (first_value_type == "c_str") ||
              (first_value_type == "char");

    // 判断值是否为嵌套字典
    v_isDict = (first_value_type.find("Dict") != std::string::npos) ||
               (first_value_type == "struct") ||
               (first_value_type == "class");

    oss << "{";
    int tempCount = 0;

    for (auto &[k, v] : this->items())
    {
        // 处理键
        if (k_isStr) {
            oss << "\"" << __pnt__.my_to_string(k) << "\"";
        } else {
            oss << __pnt__.my_to_string(k);
        }

        oss << ":";

        // 处理值
        if (v_isStr) {
            oss << "\"" << __pnt__.my_to_string(v) << "\"";
        }
        else if (v_isDict) {
            // 递归处理嵌套字典
            try {
                // 创建临时字典来递归调用
                wkp::Dict<Key, Value> tempDict;
                // 这里需要根据实际类型进行适当的递归处理
                oss << __pnt__.my_to_string(v); // 简化处理
            }
            catch (...) {
                // 如果递归失败，使用普通方式处理
                oss << __pnt__.my_to_string(v);
            }
        }
        else {
            oss << __pnt__.my_to_string(v);
        }

        // 添加逗号分隔（最后一个元素不加）
        if (tempCount < this->size() - 1) {
            oss << ", ";
        }
        tempCount++;
    }
    oss << "}";
    return oss.str();
}

// 写入json //
template <class K,class V>
void wkp::Open::writeJson(Dict<K, V> dicts)
{
    string dictString = dicts.dictToString();
    opt<<dictString;
}
/************** 映射Println与Print **************/
// println实现 //
template<typename T, typename... Args>
void wkp::println(const T &first, const Args &...rest)
{
    // 检查第一个参数是否是格式字符串
    if constexpr (std::is_convertible_v<T, std::string> && sizeof...(rest) > 0) {
        std::string fmt_str = __pnt__.my_to_string(first);

        // 检查字符串中是否包含花括号
        auto [brace_count, valid] = __pnt__.count_braces(fmt_str);

        if (brace_count > 0 && brace_count <= sizeof...(rest)) {
            // 使用格式化输出
            std::string formatted = __pnt__.my_format(fmt_str, rest...);
            std::cout << formatted << std::endl;
            return;
        }
    }

    // 普通输出
    print(first, rest...);
    std::cout << std::endl;
}

// 颜色输出 //
template<typename T, typename... Args>
void wkp::println(const Color &colors, const T &first, const Args &...rest)
{
    Print::setColor(colors);
    // 检查第一个参数是否是格式字符串
    if constexpr (std::is_convertible_v<T, std::string> && sizeof...(rest) > 0)
    {
        std::string fmt_str = __pnt__.my_to_string(first);

        // 检查字符串中是否包含花括号
        auto [brace_count, valid] = __pnt__.count_braces(fmt_str);

        if (brace_count > 0 && brace_count <= sizeof...(rest)) {
            // 使用格式化输出
            std::string formatted = __pnt__.my_format(fmt_str, rest...);
            std::cout << formatted << std::endl;
            Print::resetColor();
            return;
        }
    }

    // 普通输出
    print(first, rest...);
    std::cout << std::endl;
    Print::resetColor();
}

// print实现 //
template<typename T, typename... Args>
void wkp::print(const T& first, const Args&... rest)
{
    // 检查是否需要格式化
    if constexpr (std::is_convertible_v<T, std::string> && sizeof...(rest) > 0) {
        std::string fmt_str = __pnt__.my_to_string(first);

        auto [brace_count, valid] = __pnt__.count_braces(fmt_str);

        if (brace_count > 0 && brace_count <= sizeof...(rest)) {
            std::string formatted = __pnt__.my_format(fmt_str, rest...);
            std::cout << formatted;
            return;
        }
    }

    // 普通输出或彩色文本处理
    if constexpr (std::is_same_v<std::decay_t<T>, __ColoredText__>) {
        Print::setColor(first.getColor());
        std::cout << first.getText();
        Print::resetColor();
    } else {
        std::string first_str = __pnt__.my_to_string(first);
        std::cout << first_str;
    }

    // 处理剩余参数
    if constexpr (sizeof...(rest) > 0) {
        print(rest...);
    }
}

// 颜色输出 //
template<typename T, typename... Args>
void wkp::print(const Color &colors, const T &first, const Args &...rest)
{
    Print::setColor(colors);
    // 检查是否需要格式化
    if constexpr (std::is_convertible_v<T, std::string> && sizeof...(rest) > 0)
    {
        std::string fmt_str = __pnt__.my_to_string(first);

        auto [brace_count, valid] = __pnt__.count_braces(fmt_str);

        if (brace_count > 0 && brace_count <= sizeof...(rest)) {
            std::string formatted = __pnt__.my_format(fmt_str, rest...);
            std::cout << formatted;
            Print::resetColor();
            return;
        }
    }

    std::string first_str = __pnt__.my_to_string(first);
    std::cout << first_str;


    // 处理剩余参数
    if constexpr (sizeof...(rest) > 0)
    {
        print(rest...);
    }

    Print::resetColor();
}

/************** 映射Format **************/
// 最终函数 //
template<typename... Args>
std::string wkp::format(const std::string& fmt, Args&&... args)
{
    FormatWkp fmts;
    return fmts.format(fmt.c_str(), std::forward<Args>(args)...);
}


// 回调清理函数 //
void ExitCheckWork();