#include <iostream>
#include <winKeyPressH.hpp>
#include <unistd.h>
#include <cstdio>
#include <mutex>
#include <atomic>
#include <windows.h>
#include <vector>
using namespace std;

vector<MousePosition> PositionList;

KeyBoardEvent k;


bool run = true;

void T_Mouse()
{
    MouseEvent mouse;
    mouse.ListenMouseEvent();
}

void T_Key()
{
    ;
}



int main()
{
    ImagePosition img = GetImagePosition("img.png", 0.85);
    cout << img.x << " " << img.y << endl;
    return 0;
}

