#include "appH.hpp"

int main()
{
    MyClass obj;
    obj.doSomething();
    return 0;
}